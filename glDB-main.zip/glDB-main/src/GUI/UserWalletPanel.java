package GUI;

import javax.swing.*;
import java.awt.*;

public class UserWalletPanel extends JPanel {
    public UserWalletPanel(GameLibraryApp frame) {

    }
}