package GUI;

import javax.swing.*;

public class GamePatchPanel extends JPanel {
    public GamePatchPanel(GameLibraryApp frame) {

    }
}
