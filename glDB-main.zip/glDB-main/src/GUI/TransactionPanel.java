package GUI;

import javax.swing.*;
import java.awt.*;

public class TransactionPanel extends JPanel {
    public TransactionPanel(GameLibraryApp frame) {

    }
}