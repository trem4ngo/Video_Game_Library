package GUI;

import javax.swing.*;
import java.awt.*;

public class UserListPanel extends JPanel {
    public UserListPanel(GameLibraryApp frame) {

    }
}
