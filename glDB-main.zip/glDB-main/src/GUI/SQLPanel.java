package GUI;

import javax.swing.*;
import java.awt.*;

public class SQLPanel extends JPanel{
    public SQLPanel(GameLibraryApp frame) {

    }
}
