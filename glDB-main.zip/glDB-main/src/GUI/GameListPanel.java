package GUI;

import javax.swing.*;
import java.awt.*;

public class GameListPanel extends JPanel {
    public GameListPanel(GameLibraryApp frame) {

    }
}
