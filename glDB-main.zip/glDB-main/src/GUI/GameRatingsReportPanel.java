package GUI;

import javax.swing.*;

public class GameRatingsReportPanel extends JPanel {
    public GameRatingsReportPanel(GameLibraryApp frame) {

    }
}
