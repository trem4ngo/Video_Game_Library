package GUI;

import javax.swing.*;
import java.awt.*;

public class TransactionListPanel extends JPanel {
    public TransactionListPanel(GameLibraryApp frame) {

    }
}
