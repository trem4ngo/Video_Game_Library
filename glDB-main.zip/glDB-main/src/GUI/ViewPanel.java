package GUI;

import javax.swing.*;
import java.awt.*;

public class ViewPanel extends JFrame{
    public ViewPanel(GameLibraryApp frame) {

    }
}
