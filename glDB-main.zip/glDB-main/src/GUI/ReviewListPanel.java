package GUI;

import javax.swing.*;
import java.awt.*;

public class ReviewListPanel extends JPanel {
    public ReviewListPanel(GameLibraryApp frame) {

    }
}
