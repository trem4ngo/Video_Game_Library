package GUI;

import javax.swing.*;
import java.awt.*;

public class UserLoginPanel extends JFrame{
    public UserLoginPanel(GameLibraryApp frame) {

    }
}
