package GUI;

import javax.swing.*;
import java.awt.*;

public class UserProfilePanel extends JPanel{
    public UserProfilePanel(GameLibraryApp frame) {

    }
}