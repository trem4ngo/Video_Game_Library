package GUI;

import javax.swing.*;
import java.awt.*;

public class GameStorePanel extends JPanel {
    public GameStorePanel(GameLibraryApp frame) {

    }
}