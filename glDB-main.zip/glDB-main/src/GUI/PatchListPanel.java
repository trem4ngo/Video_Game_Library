package GUI;

import javax.swing.*;
import java.awt.*;

public class PatchListPanel extends JPanel {
    public PatchListPanel(GameLibraryApp frame) {

    }
}
