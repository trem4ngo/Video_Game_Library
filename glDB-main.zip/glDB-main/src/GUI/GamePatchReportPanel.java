package GUI;

import javax.swing.*;
import java.awt.*;

public class GamePatchReportPanel extends JPanel {
    public GamePatchReportPanel(GameLibraryApp frame) {

    }
}
