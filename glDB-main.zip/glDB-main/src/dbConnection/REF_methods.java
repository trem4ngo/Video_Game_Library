package dbConnection;

public class REF_methods {

    private int method_id;
    private String method_name;
    private String method_description;
    private boolean is_active;

    public REF_methods(int method_id, String method_name, String method_description, boolean is_active){
        this.method_id = method_id;
        this.method_name = method_name;
        this.method_description = method_description;
        this.is_active = is_active;
    }

    // Constructor with no method_id
    public REF_methods(String method_name, String method_description, boolean is_active){
        this.method_name = method_name;
        this.method_description = method_description;
        this.is_active = is_active;
    }

    public int getMethodID() {return method_id;}
    public String getMethodName() {return method_name;}
    public String getMethodDescription() {return method_description;}
    public boolean isActive() {return  is_active;}

    public void setMethodID (int method_id){this.method_id = method_id;}
    public void setMethodName (String method_name){this.method_name = method_name;}
    public void setMethod_description (String method_description) {this.method_description = method_description;}
    public void setIsActive (boolean is_active) {this.is_active = is_active;}
}
