package dbConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class REF_methods {



    private int method_id;
    private String method_name;
    private String method_description;
    private boolean is_active;

    public REF_methods(int method_id, String method_name, String method_description, boolean is_active){
        this.method_id = method_id;
        this.method_name = method_name;
        this.method_description = method_description;
        this.is_active = is_active;
    }

    // Constructor with no method_id
    public REF_methods(String method_name, String method_description, boolean is_active){
        this.method_name = method_name;
        this.method_description = method_description;
        this.is_active = is_active;
    }

    public int getMethod_id() {return method_id;}

    public void setMethod_id(int method_id) {this.method_id = method_id;}

    public String getMethod_name() {return method_name;}

    public void setMethod_name(String method_name) {this.method_name = method_name;}

    public String getMethod_description() {return method_description;}

    public void setMethod_description(String method_description) {this.method_description = method_description;}

    public boolean isIs_active() {return is_active;}

    public void setIs_active(boolean is_active) {this.is_active = is_active;}

    public static void addMethod(REF_methods method) throws SQLException {
        Connection conn = SQLConnection.getConnection();
        String sql = "INSERT INTO REF_Methods (method_name, method_description, is_active) VALUES (?, ?, ?)";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, method.getMethod_name());
        ps.setString(2, method.getMethod_description());
        ps.setBoolean(3, method.isIs_active());
        ps.executeUpdate();
        ps.close();
        conn.close();
    }

    public static List<REF_methods> getAllMethods() throws SQLException {
        List<REF_methods> methodList = new ArrayList<>();
        Connection conn = SQLConnection.getConnection();
        String sql = "SELECT * FROM REF_Methods";
        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            REF_methods method = new REF_methods(
                    rs.getInt("method_id"),
                    rs.getString("method_name"),
                    rs.getString("method_description"),
                    rs.getBoolean("is_active")
            );
            methodList.add(method);
        }

        rs.close();
        ps.close();
        conn.close();
        return methodList;
    }

    public static REF_methods getMethodByID(int method_id) throws SQLException {
        Connection conn = SQLConnection.getConnection();
        String sql = "SELECT * FROM REF_Methods WHERE method_id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, method_id);
        ResultSet rs = ps.executeQuery();

        REF_methods method = null;
        if (rs.next()) {
            method = new REF_methods(
                    rs.getInt("method_id"),
                    rs.getString("method_name"),
                    rs.getString("method_description"),
                    rs.getBoolean("is_active")
            );
        }

        rs.close();
        ps.close();
        conn.close();
        return method;
    }

    public static void updateMethod(REF_methods method) throws SQLException {
        Connection conn = SQLConnection.getConnection();
        String sql = "UPDATE REF_Methods SET method_name = ?, method_description = ?, is_active = ? WHERE method_id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, method.getMethod_name());
        ps.setString(2, method.getMethod_description());
        ps.setBoolean(3, method.isIs_active());
        ps.setInt(4, method.getMethod_id());
        ps.executeUpdate();
        ps.close();
        conn.close();
    }

    public static void deleteMethod(int method_id) throws SQLException {
        Connection conn = SQLConnection.getConnection();
        String sql = "DELETE FROM REF_Methods WHERE method_id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, method_id);
        ps.executeUpdate();
        ps.close();
        conn.close();
    }
}
