package dbConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class reviews {

    private int review_id;
    private int game_id;
    private int user_id;
    private String review_text;
    private java.sql.Date review_date;
    private int rating;

    public reviews (int review_id, int game_id, int user_id, int rating, String review_text, java.sql.Date review_date){
        this.review_id = review_id;
        this.game_id = game_id;
        this.game_id = game_id;
        this.review_text = review_text;
        this.rating = rating;
        this.review_date = review_date;
    }

    public int getReview_id() {return review_id;}

    public void setReview_id(int review_id) {this.review_id = review_id;}

    public int getGame_id() {return game_id;}

    public void setGame_id(int game_id) {this.game_id = game_id;}

    public int getUser_id() {return user_id;}

    public void setUser_id(int user_id) {this.user_id = user_id;}

    public String getReview_text() {return review_text;}

    public void setReview(String review_text) {this.review_text = review_text;}

    public void setReview_text(String review_text) {this.review_text = review_text;}

    public java.sql.Date getReview_date() {return review_date;}

    public void setReview_date(java.sql.Date review_date) {this.review_date = review_date;}

    public int getRating() {return rating;}

    public void setRating(int rating) {this.rating = rating;}

    public static void addReview(reviews review) throws SQLException {
        Connection conn = SQLConnection.getConnection();
        String sql = "INSERT INTO reviews (user_id, game_id, rating, review_text, review_date) VALUES (?, ?, ?, ?, ?)";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, review.getUser_id());
        ps.setInt(2, review.getGame_id());
        ps.setInt(3, review.getRating());
        ps.setString(4, review.getReview_text());
        ps.setDate(5, review.getReview_date());
        ps.executeUpdate();
        ps.close();
        conn.close();
    }

    public static List<reviews> getAllReviews() throws SQLException {
        List<reviews> reviewList = new ArrayList<>();
        Connection conn = SQLConnection.getConnection();
        String sql = "SELECT * FROM reviews";
        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            reviews review = new reviews(
                    rs.getInt("review_id"),
                    rs.getInt("user_id"),
                    rs.getInt("game_id"),
                    rs.getInt("review_text"),
                    rs.getString("review_text"),
                    rs.getDate("review_date")
            );
            reviewList.add(review);
        }

        rs.close();
        ps.close();
        conn.close();
        return reviewList;
    }

    public static reviews getReviewByID(int review_id) throws SQLException {
        Connection conn = SQLConnection.getConnection();
        String sql = "SELECT * FROM reviews WHERE review_id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, review_id);
        ResultSet rs = ps.executeQuery();

        reviews review = null;
        if (rs.next()) {
            review = new reviews(
                    rs.getInt("review_id"),
                    rs.getInt("user_id"),
                    rs.getInt("game_id"),
                    rs.getInt("rating"),
                    rs.getString("review_text"),
                    rs.getDate("review_date")
            );
        }

        rs.close();
        ps.close();
        conn.close();
        return review;
    }

    public static void updateReview(reviews review) throws SQLException {
        Connection conn = SQLConnection.getConnection();
        String sql = "UPDATE reviews SET user_id = ?, game_id = ?, rating = ?, review_text = ?, review_date = ? WHERE review_id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, review.getUser_id());
        ps.setInt(2, review.getGame_id());
        ps.setInt(3, review.getRating());
        ps.setString(4, review.getReview_text());
        ps.setDate(5, review.getReview_date());
        ps.setInt(6, review.getReview_id());
        ps.executeUpdate();
        ps.close();
        conn.close();
    }

    public static void deleteReview(int review_id) throws SQLException {
        Connection conn = SQLConnection.getConnection();
        String sql = "DELETE FROM reviews WHERE review_id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, review_id);
        ps.executeUpdate();
        ps.close();
        conn.close();
    }
}