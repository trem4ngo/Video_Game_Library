package dbConnection;

import java.sql.*;
import java.util.ArrayList;

public class GameTrendsReport {

    public static class TrendSummary {
        public int quarter;
        public int unitsSold;

        public TrendSummary(int quarter, int unitsSold) {
            this.quarter = quarter;
            this.unitsSold = unitsSold;
        }

        @Override
        public String toString() {
            return "Q" + quarter + ": " + unitsSold + " units sold";
        }
    }

    public static ArrayList<TrendSummary> generateReport(int year) {
        ArrayList<TrendSummary> results = new ArrayList<>();

        try (Connection conn = SQLConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "SELECT QUARTER(purchase_date) AS quarter, COUNT(*) AS units_sold " +
                             "FROM transactions " +
                             "WHERE YEAR(purchase_date) = ? " +
                             "GROUP BY QUARTER(purchase_date) " +
                             "ORDER BY quarter")) {

            stmt.setInt(1, year);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                int quarter = rs.getInt("quarter");
                int units = rs.getInt("units_sold");
                results.add(new TrendSummary(quarter, units));
            }

        } catch (SQLException e) {
            System.out.println("Error generating game trends report: " + e.getMessage());
        }

        return results;
    }

    /*Testing
    public static void main(String[] args) {
        int year = 2024;
        ArrayList<TrendSummary> report = generateReport(year);

        System.out.println("Game Trends Report for " + year);
        for (TrendSummary summary : report) {
            System.out.println(summary);
        }
    }
    */
}