package dbConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class REF_platforms {

    private int platform_id;
    private String platform_type;
    private String platform_name;

    public REF_platforms (int platform_id, String platform_type, String platform_name){
        this.platform_id = platform_id;
        this.platform_name = platform_name;
        this.platform_type = platform_type;
    }

    public int getPlatform_id() {return platform_id;}

    public void setPlatform_id(int platform_id) {this.platform_id = platform_id;}

    public String getPlatform_type() {return platform_type;}

    public void setPlatform_type(String platform_type) {this.platform_type = platform_type;}

    public String getPlatform_name() {return platform_name;}

    public void setPlatform_name(String platform_name) {this.platform_name = platform_name;}

    public static void addPlatform(REF_platforms platform) throws SQLException {
        Connection conn = SQLConnection.getConnection();
        String sql =
                "INSERT INTO REF_Platforms (platform_type, platform_name) " +
                        "VALUES (?, ?)";

        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, platform.getPlatform_type());
        ps.setString(2, platform.getPlatform_name());
        ps.executeUpdate();
        ps.close();
        conn.close();
    }

    public static List<REF_platforms> getAllPlatforms() throws SQLException {
        List<REF_platforms> platformList = new ArrayList<>();
        Connection conn = SQLConnection.getConnection();
        String sql =
                "SELECT * " +
                        "FROM REF_Platforms";

        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            REF_platforms platform = new REF_platforms(
                    rs.getInt("platform_id"),
                    rs.getString("platform_type"),
                    rs.getString("platform_name")
            );
            platformList.add(platform);
        }

        rs.close();
        ps.close();
        conn.close();
        return platformList;
    }

    public static REF_platforms getPlatformByID(int platform_id) throws SQLException {
        Connection conn = SQLConnection.getConnection();
        String sql =
                "SELECT * " +
                        "FROM REF_Platforms " +
                        "WHERE platform_id = ?";

        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, platform_id);
        ResultSet rs = ps.executeQuery();

        REF_platforms platform = null;
        if (rs.next()) {
            platform = new REF_platforms(
                    rs.getInt("platform_id"),
                    rs.getString("platform_type"),
                    rs.getString("platform_name")
            );
        }

        rs.close();
        ps.close();
        conn.close();
        return platform;
    }

    public static void updatePlatform(REF_platforms platform) throws SQLException {
        Connection conn = SQLConnection.getConnection();
        String sql =
                "UPDATE REF_Platforms " +
                        "SET platform_type = ?, platform_name = ? " +
                        "WHERE platform_id = ?";

        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, platform.getPlatform_type());
        ps.setString(2, platform.getPlatform_name());
        ps.setInt(3, platform.getPlatform_id());
        ps.executeUpdate();
        ps.close();
        conn.close();
    }

    public static void deletePlatform(int platform_id) throws SQLException {
        Connection conn = SQLConnection.getConnection();
        String sql =
                "DELETE FROM REF_Platforms " +
                        "WHERE platform_id = ?";

        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, platform_id);
        ps.executeUpdate();
        ps.close();
        conn.close();
    }
}
