package dbConnection;

import java.sql.*;
import java.util.ArrayList;

public class FinancialSummaryReport {

    public static class RevenueSummary {
        public int quarter;
        public double revenue;

        public RevenueSummary(int quarter, double revenue) {
            this.quarter = quarter;
            this.revenue = revenue;
        }

        @Override
        public String toString() {
            return "Q" + quarter + ": $" + String.format("%.2f", revenue);
        }
    }

    public static ArrayList<RevenueSummary> generateReport(int year) {
        ArrayList<RevenueSummary> results = new ArrayList<>();

        String query =
                "SELECT QUARTER(date) AS quarter, SUM(amount) AS revenue " +
                        "FROM (" +
                        "   SELECT purchase_date AS date, amount_paid AS amount FROM transactions WHERE YEAR(purchase_date) = ? " +
                        "   UNION ALL " +
                        "   SELECT rental_date AS date, rental_fee AS amount FROM rentals WHERE YEAR(rental_date) = ?" +
                        ") AS combined " +
                        "GROUP BY QUARTER(date) " +
                        "ORDER BY quarter";

        try (Connection conn = SQLConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, year);
            stmt.setInt(2, year);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                int quarter = rs.getInt("quarter");
                double revenue = rs.getDouble("revenue");
                results.add(new RevenueSummary(quarter, revenue));
            }

        } catch (SQLException e) {
            System.err.println("Error generating Financial Summary Report: " + e.getMessage());
        }

        return results;
    }

    /*Testing
    public static void main(String[] args) {
        int year = 2024;
        ArrayList<RevenueSummary> report = generateReport(year);

        System.out.println("Financial Summary Report for Year " + year);
        for (RevenueSummary summary : report) {
            System.out.println(summary);
        }
    }
    */
}