package dbConnection;

public class transactions {
    private int transaction_id;
    private int game_id;
    private int user_id;
    private int method_id;
    private double transaction_amount;
    private String transaction_date;
    private String online_url;
    private boolean transaction_status;

    public transactions (int transaction_id, int game_id, int user_id, int method_id, double transaction_amount,
                         String transaction_date, String online_url, boolean transaction_status){
        this.transaction_id = transaction_id;
        this.game_id = game_id;
        this.user_id = user_id;
        this.method_id = method_id;
        this.transaction_amount = transaction_amount;
        this.transaction_date = transaction_date;
        this.online_url = online_url;
        this.transaction_status = transaction_status;
    }

    public int getTransactionID() {return transaction_id;}

    public void setTransactionID(int transaction_id) {this.transaction_id = transaction_id;}

    public int getGameID() {return game_id;}

    public void setGameID(int game_id) {this.game_id = game_id;}

    public int getUserID() {return user_id;}

    public void setUserID(int user_id) {this.user_id = user_id;}

    public int getMethodID() {return method_id;}

    public void setMethodID(int method_id) {this.method_id = method_id;}

    public double getTransaction_amount() {return transaction_amount;}

    public void setTransaction_amount(double transaction_amount) {this.transaction_amount = transaction_amount;}

    public String getTransaction_date() {return transaction_date;}

    public void setTransaction_date(String transaction_date) {this.transaction_date = transaction_date;}

    public String getOnline_url() {return online_url;}

    public void setOnline_url(String online_url) {this.online_url = online_url;}

    public boolean isTransaction_status() {return transaction_status;}

    public void setTransaction_status(boolean transaction_status) {this.transaction_status = transaction_status;}
}
