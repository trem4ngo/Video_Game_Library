package dbConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class transactions {

    private int transaction_id;
    private int game_id;
    private int user_id;
    private int method_id;
    private double transaction_amount;
    private java.sql.Date transaction_date;
    private String transaction_status;

    public transactions (int transaction_id, int game_id, int user_id, int method_id, double transaction_amount,
                         java.sql.Date transaction_date, String transaction_status){
        this.transaction_id = transaction_id;
        this.game_id = game_id;
        this.user_id = user_id;
        this.method_id = method_id;
        this.transaction_amount = transaction_amount;
        this.transaction_date = transaction_date;
        this.transaction_status = transaction_status;
    }

    public int getTransaction_id() {return transaction_id;}

    public void setTransaction_id(int transaction_id) {this.transaction_id = transaction_id;}

    public int getGame_id() {return game_id;}

    public void setGame_id(int game_id) {this.game_id = game_id;}

    public int getUser_id() {return user_id;}

    public void setUser_id(int user_id) {this.user_id = user_id;}

    public int getMethod_id() {return method_id;}

    public void setMethod_id(int method_id) {this.method_id = method_id;}

    public double getTransaction_amount() {return transaction_amount;}

    public void setTransaction_amount(double transaction_amount) {this.transaction_amount = transaction_amount;}

    public Date getTransaction_date() {return transaction_date;}

    public void setTransaction_date(Date transaction_date) {this.transaction_date = transaction_date;}

    public String getTransaction_status() {return transaction_status;}

    public void setTransaction_status(String transaction_status) {this.transaction_status = transaction_status;}


    public static void addTransaction(transactions t) throws SQLException {
        Connection conn = SQLConnection.getConnection();
        String sql = "INSERT INTO Transactions (game_id, user_id, method_id, transaction_amount, transaction_date, transaction_status) VALUES (?, ?, ?, ?, ?, ?)";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, t.getGame_id());
        ps.setInt(2, t.getUser_id());
        ps.setInt(3, t.getMethod_id());
        ps.setDouble(4, t.getTransaction_amount());
        ps.setDate(5, t.getTransaction_date());
        ps.setString(6, t.getTransaction_status());
        ps.executeUpdate();
        ps.close();
        conn.close();
    }

    public static List<transactions> getAllTransactions() throws SQLException {
        List<transactions> transactionList = new ArrayList<>();
        Connection conn = SQLConnection.getConnection();
        String sql = "SELECT * FROM Transactions";
        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            transactions t = new transactions(
                    rs.getInt("transaction_id"),
                    rs.getInt("game_id"),
                    rs.getInt("user_id"),
                    rs.getInt("method_id"),
                    rs.getDouble("transaction_amount"),
                    rs.getDate("transaction_date"),
                    rs.getString("transaction_status")
            );
            transactionList.add(t);
        }

        rs.close();
        ps.close();
        conn.close();
        return transactionList;
    }

    public static transactions getTransactionByID(int transaction_id) throws SQLException {
        Connection conn = SQLConnection.getConnection();
        String sql = "SELECT * FROM Transactions WHERE transaction_id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, transaction_id);
        ResultSet rs = ps.executeQuery();

        transactions t = null;
        if (rs.next()) {
            t = new transactions(
                    rs.getInt("transaction_id"),
                    rs.getInt("game_id"),
                    rs.getInt("user_id"),
                    rs.getInt("method_id"),
                    rs.getDouble("transaction_amount"),
                    rs.getDate("transaction_date"),
                    rs.getString("transaction_status")
            );
        }

        rs.close();
        ps.close();
        conn.close();
        return t;
    }

    public static void updateTransaction(transactions t) throws SQLException {
        Connection conn = SQLConnection.getConnection();
        String sql = "UPDATE Transactions SET game_id = ?, user_id = ?, method_id = ?, transaction_amount = ?, transaction_date = ?, transaction_status = ? WHERE transaction_id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, t.getGame_id());
        ps.setInt(2, t.getUser_id());
        ps.setInt(3, t.getMethod_id());
        ps.setDouble(4, t.getTransaction_amount());
        ps.setDate(5, t.getTransaction_date());
        ps.setString(6, t.getTransaction_status());
        ps.setInt(7, t.getTransaction_id());
        ps.executeUpdate();
        ps.close();
        conn.close();
    }

    public static void deleteTransaction(int transaction_id) throws SQLException {
        Connection conn = SQLConnection.getConnection();
        String sql = "DELETE FROM Transactions WHERE transaction_id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, transaction_id);
        ps.executeUpdate();
        ps.close();
        conn.close();
    }
}
