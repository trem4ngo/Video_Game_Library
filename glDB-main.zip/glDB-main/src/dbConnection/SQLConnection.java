package dbConnection;//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class SQLConnection {
    public SQLConnection() {
    }

    public static Connection getConnection() {
        Connection conn = null;

        try {
            String URL = "jdbc:mysql://localhost:3306/gamelibrary";
            String USERNAME = "root";
            String PASSWORD = "12345678";
            conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            if (conn != null) {
                System.out.println("Connection successful!");
            }
        } catch (SQLException var4) {
            System.out.println("Connection failed!");
            System.out.println(var4.getMessage());
        }

        return conn;
    }

    public static void main(String[] args) {
        getConnection();
    }
}
