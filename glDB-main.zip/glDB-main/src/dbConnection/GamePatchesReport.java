package dbConnection;

import java.sql.*;
import java.util.*;

public class GamePatchesReport {

    public static class PatchSummary {
        private int game_id;
        private String game_name;
        private java.sql.Date patch_date;
        private int num_builds;

        public PatchSummary(int game_id, String game_name, java.sql.Date patch_date, int num_builds) {
            this.game_id = game_id;
            this.game_name = game_name;
            this.patch_date = patch_date;
            this.num_builds = num_builds;
        }

        @Override
        public String toString() {
            return String.format(
                    "Game: %-30s | Date: %s | Builds: %d",
                    game_name, patch_date.toString(), num_builds
            );
        }
    }

    public static List<PatchSummary> generateReport(int year, int month) throws SQLException {
        List<PatchSummary> report = new ArrayList<>();

        String sql = """
                    SELECT 
                        p.game_id,
                        g.game_name,
                        p.patch_date,
                        COUNT(*) AS num_builds
                    FROM Patches p
                    JOIN Games g ON p.game_id = g.game_id
                    WHERE YEAR(p.patch_date) = ? AND MONTH(p.patch_date) = ?
                    GROUP BY p.game_id, g.game_name, p.patch_date
                    ORDER BY g.game_name, p.patch_date
                """;

        Connection conn = SQLConnection.getConnection();
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, year);
        ps.setInt(2, month);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            PatchSummary summary = new PatchSummary(
                    rs.getInt("game_id"),
                    rs.getString("game_name"),
                    rs.getDate("patch_date"),
                    rs.getInt("num_builds")
            );
            report.add(summary);
        }

        rs.close();
        ps.close();
        conn.close();

        return report;
    }
}