package dbConnection;

public class wallets {

    private int wallet_id;
    private int user_id;
    private double wallet_balance;

    public wallets(int wallet_id, int user_id, double wallet_balance) {
        this.wallet_id = wallet_id;
        this.user_id = user_id;
        this.wallet_balance = wallet_balance;
    }

    //Constructor with no wallet_id
    public wallets(int user_id, double wallet_balance) {
        this.user_id = user_id;
        this.wallet_balance = wallet_balance;
    }

    public int getWalletID() { return wallet_id; }
    public int getUserID() { return user_id; }
    public double getWalletBalance() { return wallet_balance; }

    public void setWalletID (int wallet_id) {this.wallet_id = wallet_id;}
    public void setUserID (int user_id) {this.user_id = user_id;}
    public void setWalletBalance (double wallet_balance) {this.wallet_balance = wallet_balance;}
}