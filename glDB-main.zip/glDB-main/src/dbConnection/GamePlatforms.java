package dbConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class GamePlatforms {

    private int game_id;
    private int platform_id;

    public GamePlatforms (int game_id, int platform_id){
        this.game_id = game_id;
        this.platform_id = platform_id;
    }

    public int getGame_id() {return game_id;}

    public void setGame_id(int game_id) {this.game_id = game_id;}

    public int getPlatform_id() {return platform_id;}

    public void setPlatform_id(int platform_id) {this.platform_id = platform_id;}

    public static void addGamePlatform(GamePlatforms gp) throws SQLException {
        Connection conn = SQLConnection.getConnection();
        String sql =
                "INSERT INTO Game_Platforms (game_id, platform_id) " +
                        "VALUES (?, ?)";

        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, gp.getGame_id());
        ps.setInt(2, gp.getPlatform_id());
        ps.executeUpdate();
        ps.close();
        conn.close();
    }

    public static List<GamePlatforms> getAllGamePlatforms() throws SQLException {
        List<GamePlatforms> list = new ArrayList<>();
        Connection conn = SQLConnection.getConnection();
        String sql =
                "SELECT * " +
                        "FROM Game_Platforms";

        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            GamePlatforms gp = new GamePlatforms(
                    rs.getInt("game_id"),
                    rs.getInt("platform_id")
            );
            list.add(gp);
        }

        rs.close();
        ps.close();
        conn.close();
        return list;
    }

    // Reading through composite key
    public static GamePlatforms getGamePlatform(int game_id, int platform_id) throws SQLException {
        Connection conn = SQLConnection.getConnection();
        String sql =
                "SELECT * " +
                        "FROM Game_Platforms " +
                        "WHERE game_id = ? AND platform_id = ?";

        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, game_id);
        ps.setInt(2, platform_id);
        ResultSet rs = ps.executeQuery();

        GamePlatforms gp = null;
        if (rs.next()) {
            gp = new GamePlatforms(rs.getInt("game_id"), rs.getInt("platform_id"));
        }

        rs.close();
        ps.close();
        conn.close();
        return gp;
    }

    public static void deleteGamePlatform(int game_id, int platform_id) throws SQLException {
        Connection conn = SQLConnection.getConnection();
        String sql =
                "DELETE FROM Game_Platforms " +
                        "WHERE game_id = ? AND platform_id = ?";

        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, game_id);
        ps.setInt(2, platform_id);
        ps.executeUpdate();
        ps.close();
        conn.close();
    }
}
