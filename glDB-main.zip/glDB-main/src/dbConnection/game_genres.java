package dbConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class game_genres {

    private int genre_id;
    private int game_id;

    public game_genres (int genre_id, int game_id){
        this.game_id = game_id;
        this.genre_id = genre_id;
    }

    public int getGenre_id() {return genre_id;}

    public void setGenre_id(int genre_id) {this.genre_id = genre_id;}

    public int getGame_id() {return game_id;}

    public void setGame_id(int game_id) {this.game_id = game_id;}

    public static void addGameGenre(game_genres gg) throws SQLException {
        Connection conn = SQLConnection.getConnection();
        String sql = "INSERT INTO Game_Genres (game_id, genre_id) VALUES (?, ?)";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, gg.getGame_id());
        ps.setInt(2, gg.getGenre_id());
        ps.executeUpdate();
        ps.close();
        conn.close();
    }

    public static List<game_genres> getAllGameGenres() throws SQLException {
        List<game_genres> list = new ArrayList<>();
        Connection conn = SQLConnection.getConnection();
        String sql = "SELECT * FROM Game_Genres";
        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            game_genres gg = new game_genres(
                    rs.getInt("game_id"),
                    rs.getInt("genre_id")
            );
            list.add(gg);
        }

        rs.close();
        ps.close();
        conn.close();
        return list;
    }

    public static game_genres getGameGenre(int game_id, int genre_id) throws SQLException {
        Connection conn = SQLConnection.getConnection();
        String sql = "SELECT * FROM Game_Genres WHERE game_id = ? AND genre_id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, game_id);
        ps.setInt(2, genre_id);
        ResultSet rs = ps.executeQuery();

        game_genres gg = null;
        if (rs.next()) {
            gg = new game_genres(rs.getInt("game_id"), rs.getInt("genre_id"));
        }

        rs.close();
        ps.close();
        conn.close();
        return gg;
    }

    public static void deleteGameGenre(int game_id, int genre_id) throws SQLException {
        Connection conn = SQLConnection.getConnection();
        String sql = "DELETE FROM Game_Genres WHERE game_id = ? AND genre_id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, game_id);
        ps.setInt(2, genre_id);
        ps.executeUpdate();
        ps.close();
        conn.close();
    }
}
