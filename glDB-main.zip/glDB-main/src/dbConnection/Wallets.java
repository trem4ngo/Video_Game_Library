package dbConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Wallets {

    private int wallet_id;
    private int user_id;
    private double wallet_balance;

    public Wallets(int wallet_id, int user_id, double wallet_balance) {
        this.wallet_id = wallet_id;
        this.user_id = user_id;
        this.wallet_balance = wallet_balance;
    }

    public int getWallet_id() {return wallet_id;}

    public void setWallet_id(int wallet_id) {this.wallet_id = wallet_id;}

    public int getUser_id() {return user_id;}

    public void setUser_id(int user_id) {this.user_id = user_id;}

    public double getWallet_balance() {return wallet_balance;}

    public void setWallet_balance(double wallet_balance) {this.wallet_balance = wallet_balance;}

    //Constructor with no wallet_id
    public Wallets(int user_id, double wallet_balance) {
        this.user_id = user_id;
        this.wallet_balance = wallet_balance;
    }

    public static void addWallet(Wallets wallet) throws SQLException {
        Connection conn = SQLConnection.getConnection();
        String sql =
                "INSERT INTO wallets (user_id, balance, last_updated) " +
                        "VALUES (?, ?, ?)";

        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, wallet.getUser_id());
        ps.setDouble(2, wallet.getWallet_balance());
        ps.executeUpdate();
        ps.close();
        conn.close();
    }

    // Reading all data
    public static List<Wallets> getAllWallets() throws SQLException {
        List<Wallets> walletList = new ArrayList<>();
        Connection conn = SQLConnection.getConnection();
        String sql =
                "SELECT * " +
                        "FROM wallets";

        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            Wallets wallet = new Wallets(
                    rs.getInt("wallet_id"),
                    rs.getInt("user_id"),
                    rs.getDouble("balance")
            );
            walletList.add(wallet);
        }

        rs.close();
        ps.close();
        conn.close();
        return walletList;
    }

    //Reading a single data
    public static Wallets getWalletByID(int wallet_id) throws SQLException {
        Connection conn = SQLConnection.getConnection();
        String sql =
                "SELECT * " +
                        "FROM wallets " +
                        "WHERE wallet_id = ?";

        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, wallet_id);
        ResultSet rs = ps.executeQuery();

        Wallets wallet = null;
        if (rs.next()) {
            wallet = new Wallets(
                    rs.getInt("wallet_id"),
                    rs.getInt("user_id"),
                    rs.getDouble("balance")
            );
        }

        rs.close();
        ps.close();
        conn.close();
        return wallet;
    }

    public static void updateWallet(Wallets wallet) throws SQLException {
        Connection conn = SQLConnection.getConnection();
        String sql =
                "UPDATE wallets " +
                        "SET user_id = ?, balance = ?, last_updated = ? " +
                        "WHERE wallet_id = ?";

        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, wallet.getUser_id());
        ps.setDouble(2, wallet.getWallet_balance());
        ps.setInt(4, wallet.getWallet_id());
        ps.executeUpdate();
        ps.close();
        conn.close();
    }

    public static void deleteWallet(int wallet_id) throws SQLException {
        Connection conn = SQLConnection.getConnection();
        String sql =
                "DELETE FROM wallets " +
                        "WHERE wallet_id = ?";

        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, wallet_id);
        ps.executeUpdate();
        ps.close();
        conn.close();
    }
}