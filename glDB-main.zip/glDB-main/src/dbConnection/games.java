package dbConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class games {

    private int game_id;
    private String game_name;
    private java.sql.Date release_date;
    private String developer;
    private String publisher;
    private boolean availability;
    private double price;

    //Constructor with game_id
    public games (int game_id, String game_name, java.sql.Date release_date, String developer, String publisher, boolean availability, double price)
    {
        this.game_id = game_id;
        this.game_name = game_name;
        this.release_date = release_date;
        this.developer = developer;
        this.publisher = publisher;
        this.availability = availability;
        this.price = price;
    }

    //Constructor without game_id
    public games (String game_name, java.sql.Date release_date, String developer, String publisher, boolean availability, double price)
    {
        this.game_name = game_name;
        this.release_date = release_date;
        this.developer = developer;
        this.publisher = publisher;
        this.availability = availability;
        this.price = price;
    }

    public int getGame_id() {return game_id;}

    public void setGame_id(int game_id) {this.game_id = game_id;}

    public String getGame_name() {return game_name;}

    public void setGame_name(String game_name) {this.game_name = game_name;}

    public Date getRelease_date() {return release_date;}

    public void setRelease_date(Date release_date) {this.release_date = release_date;}

    public String getDeveloper() {return developer;}

    public void setDeveloper(String developer) {this.developer = developer;}

    public String getPublisher() {return publisher;}

    public void setPublisher(String publisher) {this.publisher = publisher;}

    public boolean isAvailability() {return availability;}

    public void setAvailability(boolean availability) {this.availability = availability;}

    public double getPrice() {return price;}

    public void setPrice(double price) {this.price = price;}

    public static void addGame(games game) throws SQLException {
        Connection conn = SQLConnection.getConnection();
        String sql = "INSERT INTO Games (game_name, release_date, developer, publisher, availability, price) VALUES (?, ?, ?, ?, ?, ?)";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, game.getGame_name());
        ps.setDate(2, game.getRelease_date());
        ps.setString(3, game.getDeveloper());
        ps.setString(4, game.getPublisher());
        ps.setBoolean(5, game.isAvailability());
        ps.setDouble(6, game.getPrice());
        ps.executeUpdate();
        ps.close();
        conn.close();
    }

    public static List<games> getAllGames() throws SQLException {
        List<games> gameList = new ArrayList<>();
        Connection conn = SQLConnection.getConnection();
        String sql = "SELECT * FROM Games";
        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            games game = new games(
                    rs.getInt("game_id"),
                    rs.getString("game_name"),
                    rs.getDate("release_date"),
                    rs.getString("developer"),
                    rs.getString("publisher"),
                    rs.getBoolean("availability"),
                    rs.getDouble("price")
            );
            gameList.add(game);
        }

        rs.close();
        ps.close();
        conn.close();
        return gameList;
    }

    public static games getGameByID(int game_id) throws SQLException {
        Connection conn = SQLConnection.getConnection();
        String sql = "SELECT * FROM Games WHERE game_id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, game_id);
        ResultSet rs = ps.executeQuery();

        games game = null;
        if (rs.next()) {
            game = new games(
                    rs.getInt("game_id"),
                    rs.getString("game_name"),
                    rs.getDate("release_date"),
                    rs.getString("developer"),
                    rs.getString("publisher"),
                    rs.getBoolean("availability"),
                    rs.getDouble("price")
            );
        }

        rs.close();
        ps.close();
        conn.close();
        return game;
    }

    public static void updateGame(games game) throws SQLException {
        Connection conn = SQLConnection.getConnection();
        String sql = "UPDATE Games SET game_name = ?, release_date = ?, developer = ?, publisher = ?, availability = ?, price = ? WHERE game_id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, game.getGame_name());
        ps.setDate(2, game.getRelease_date());
        ps.setString(3, game.getDeveloper());
        ps.setString(4, game.getPublisher());
        ps.setBoolean(5, game.isAvailability());
        ps.setDouble(6, game.getPrice());
        ps.setInt(7, game.getGame_id());
        ps.executeUpdate();
        ps.close();
        conn.close();
    }

    public static void deleteGame(int game_id) throws SQLException {
        Connection conn = SQLConnection.getConnection();
        String sql = "DELETE FROM Games WHERE game_id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, game_id);
        ps.executeUpdate();
        ps.close();
        conn.close();
    }
}
