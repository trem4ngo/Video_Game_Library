package dbConnection;

public class games {
    private int game_id;
    private String game_name;
    private String release_date;
    private String developer;
    private String publisher;
    private boolean availability;
    private double price;

    //Constructor with game_id
    public games (int game_id, String game_name, String release_date, String developer, String publisher, boolean availability, double price)
    {
        this.game_id = game_id;
        this.game_name = game_name;
        this.release_date = release_date;
        this.developer = developer;
        this.publisher = publisher;
        this.availability = availability;
        this.price = price;
    }

    //Constructor without game_id
    public games (String game_name, String release_date, String developer, String publisher, boolean availability, double price)
    {
        this.game_name = game_name;
        this.release_date = release_date;
        this.developer = developer;
        this.publisher = publisher;
        this.availability = availability;
        this.price = price;
    }

    //Getters for game values
    public int getGameID() {return game_id;}
    public String getGameName () {return game_name;}
    public String getReleaseDate() {return release_date;}
    public String getDeveloper() {return developer;}
    public String getPublisher() {return publisher;}
    public boolean getAvailability() {return availability;}
    public double getPrice() {return price;}

    public void setGameID (int game_id) {this.game_id = game_id;}
    public void setGameName(String game_name){this.game_name = game_name;}
    public void setReleaseDate(String release_date){this.release_date = release_date;}
    public void setDeveloper(String developer){this.developer = developer;}
    public void setPublisher(String publisher){this.publisher = publisher;}
    public void setAvailability(boolean availability){this.availability = availability;}
    public void setPrice(double price){this.price = price;}
}
