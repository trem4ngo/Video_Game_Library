package dbConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Users {

    private int user_id;
    private String first_name;
    private String last_name;
    private java.sql.Date birth_date;
    private String sex;
    private String contact_number;
    private String contact_email;

    public Users (int user_id, String first_name, String last_name, java.sql.Date birth_date, String sex, String contact_number, String contact_email){
        this.user_id = user_id;
        this.first_name = first_name;
        this.last_name = last_name;
        this.birth_date = birth_date;
        this.sex = sex;
        this.contact_number = contact_number;
        this.contact_email = contact_email;
    }

    public int getUser_id () {return user_id;}
    public String getFirst_name () {return first_name;}
    public String getLast_name () {return last_name;}
    public java.sql.Date getBirth_date () {return birth_date;}
    public String getSex () {return sex;}
    public String getContact_number () {return contact_number;}
    public String getContact_email () {return contact_email;}

    public void setUser_id (int user_id) {this.user_id = user_id;}
    public void setFirst_name (String first_name){this.first_name = first_name;}
    public void setLast_name (String last_name){this.last_name = last_name;}
    public void setBirth_date (java.sql.Date birth_date){this.birth_date = birth_date;}
    public void setSex (String sex) {this.sex = sex;}
    public void setContact_number (String contact_number){this.contact_number = contact_number;}
    public void setContact_email (String contact_email){this.contact_email = contact_email;}

    public static List<Users> getAllUsers() throws SQLException {
        List<Users> userList = new ArrayList<>();
        Connection conn = SQLConnection.getConnection();
        String sql = "SELECT * FROM Users";
        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            Users user = new Users(
                    rs.getInt("user_id"),
                    rs.getString("first_name"),
                    rs.getString("last_name"),
                    rs.getDate("birth_date"),
                    rs.getString("sex"),
                    rs.getString("contact_number"),
                    rs.getString("contact_email")
            );
            userList.add(user);
        }

        rs.close();
        ps.close();
        conn.close();

        return userList;
    }

    public static Users getUserByID(int user_id) throws SQLException {
        Connection conn = SQLConnection.getConnection();
        String sql = "SELECT * FROM Users WHERE user_id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, user_id);
        ResultSet rs = ps.executeQuery();

        Users user = null;
        if (rs.next()) {
            user = new Users(
                    rs.getInt("user_id"),
                    rs.getString("first_name"),
                    rs.getString("last_name"),
                    rs.getDate("birth_date"),
                    rs.getString("sex"),
                    rs.getString("contact_number"),
                    rs.getString("contact_email")
            );
        }

        rs.close();
        ps.close();
        conn.close();

        return user;
    }

    public static void addUser(Users user) throws SQLException {
        Connection conn = SQLConnection.getConnection();
        String sql = "INSERT INTO Users (first_name, last_name, birth_date, sex, contact_number, contact_email) VALUES (?, ?, ?, ?, ?, ?)";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, user.getFirst_name());
        ps.setString(2, user.getLast_name());
        ps.setDate(3, user.getBirth_date());
        ps.setString(4, user.getSex());
        ps.setString(5, user.getContact_number());
        ps.setString(6, user.getContact_email());
        ps.executeUpdate();

        ps.close();
        conn.close();
    }

    public static void updateUser(Users user) throws SQLException {
        Connection conn = SQLConnection.getConnection();
        String sql = "UPDATE Users SET first_name = ?, last_name = ?, birth_date = ?, sex = ?, contact_number = ?, contact_email = ? WHERE user_id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, user.getFirst_name());
        ps.setString(2, user.getLast_name());
        ps.setDate(3, user.getBirth_date());
        ps.setString(4, user.getSex());
        ps.setString(5, user.getContact_number());
        ps.setString(6, user.getContact_email());
        ps.setInt(7, user.getUser_id());
        ps.executeUpdate();

        ps.close();
        conn.close();
    }

    public static void deleteUser(int user_id) throws SQLException {
        Connection conn = SQLConnection.getConnection();
        String sql = "DELETE FROM Users WHERE user_id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, user_id);
        ps.executeUpdate();

        ps.close();
        conn.close();
    }
}
