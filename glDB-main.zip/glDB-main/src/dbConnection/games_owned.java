package dbConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class games_owned {

    private int user_id;
    private int game_id;

    public games_owned (int user_id, int game_id){
        this.user_id = user_id;
        this.game_id = game_id;
    }

    public int getUser_id() {return user_id;}

    public void setUser_id(int user_id) {this.user_id = user_id;}

    public int getGame_id() {return game_id;}

    public void setGame_id(int game_id) {this.game_id = game_id;}

    public static void addOwnership(games_owned owned) throws SQLException {
        Connection conn = SQLConnection.getConnection();
        String sql = "INSERT INTO Games_Owned (user_id, game_id) VALUES (?, ?)";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, owned.getUser_id());
        ps.setInt(2, owned.getGame_id());
        ps.executeUpdate();
        ps.close();
        conn.close();
    }

    public static List<games_owned> getAllOwnerships() throws SQLException {
        List<games_owned> ownedList = new ArrayList<>();
        Connection conn = SQLConnection.getConnection();
        String sql = "SELECT * FROM Games_Owned";
        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            games_owned owned = new games_owned(
                    rs.getInt("user_id"),
                    rs.getInt("game_id")
            );
            ownedList.add(owned);
        }

        rs.close();
        ps.close();
        conn.close();
        return ownedList;
    }

    public static games_owned getOwnership(int user_id, int game_id) throws SQLException {
        Connection conn = SQLConnection.getConnection();
        String sql = "SELECT * FROM Games_Owned WHERE user_id = ? AND game_id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, user_id);
        ps.setInt(2, game_id);
        ResultSet rs = ps.executeQuery();

        games_owned owned = null;
        if (rs.next()) {
            owned = new games_owned(rs.getInt("user_id"), rs.getInt("game_id"));
        }

        rs.close();
        ps.close();
        conn.close();
        return owned;
    }

    public static void deleteOwnership(int user_id, int game_id) throws SQLException {
        Connection conn = SQLConnection.getConnection();
        String sql = "DELETE FROM Games_Owned WHERE user_id = ? AND game_id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, user_id);
        ps.setInt(2, game_id);
        ps.executeUpdate();
        ps.close();
        conn.close();
    }
}
