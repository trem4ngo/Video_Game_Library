package dbConnection;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class GameLibraryAppReports {
    private JFrame frame;

    public GameLibraryAppReports() {
        frame = new JFrame("Game Library System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 400);
        showMainMenu();
    }

    private void showMainMenu() {
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 1));

        JButton reportsButton = new JButton("View Reports");
        JButton exitButton = new JButton("Exit");

        reportsButton.addActionListener(e -> showReportsScreen());
        exitButton.addActionListener(e -> System.exit(0));

        panel.add(new JLabel("Welcome to the Game Library System", SwingConstants.CENTER));
        panel.add(reportsButton);
        panel.add(exitButton);

        frame.setContentPane(panel);
        frame.setVisible(true);
    }

    private void showReportsScreen() {
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(5, 1));

        JButton financialReportButton = new JButton("Financial Summary Report");
        JButton ratingsReportButton = new JButton("Game Ratings Summary Report");
        JButton patchReportButton = new JButton("Game Patch Summary Report");
        JButton trendsReportButton = new JButton("Game Trends Report");
        JButton backButton = new JButton("Back to Menu");

        financialReportButton.addActionListener(e -> showReport("Financial Summary Report", "SELECT QUARTER(transaction_date) AS period, SUM(transaction_amount) AS value FROM Transactions GROUP BY period"));
        ratingsReportButton.addActionListener(e -> showReport("Game Ratings Summary Report", "SELECT QUARTER(review_date) AS period, AVG(rating) AS value FROM Reviews GROUP BY period"));
        patchReportButton.addActionListener(e -> showReport("Game Patch Summary Report", "SELECT patch_date AS period, COUNT(patch_id) AS value FROM Patches GROUP BY patch_date"));
        trendsReportButton.addActionListener(e -> showReport("Game Trends Report", "SELECT QUARTER(transaction_date) AS period, COUNT(game_id) AS value FROM Transactions GROUP BY period"));
        backButton.addActionListener(e -> showMainMenu());

        panel.add(new JLabel("Select a Report", SwingConstants.CENTER));
        panel.add(financialReportButton);
        panel.add(ratingsReportButton);
        panel.add(patchReportButton);
        panel.add(trendsReportButton);
        panel.add(backButton);

        frame.setContentPane(panel);
        frame.setVisible(true);
    }

    private void showReport(String title, String query) {
        JFrame reportFrame = new JFrame(title);
        reportFrame.setSize(500, 400);

        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Period");
        model.addColumn("Value");

        JTable table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);

        try (Connection conn = SQLConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                model.addRow(new Object[]{rs.getString("period"), rs.getDouble("value")});
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        JButton closeButton = new JButton("Close");
        closeButton.addActionListener(e -> reportFrame.dispose());

        JPanel panel = new JPanel(new BorderLayout());
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(closeButton, BorderLayout.SOUTH);

        reportFrame.add(panel);
        reportFrame.setVisible(true);
    }
}