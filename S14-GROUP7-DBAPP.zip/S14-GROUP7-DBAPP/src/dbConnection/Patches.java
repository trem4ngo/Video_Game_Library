package dbConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Patches {

    private int patch_id;
    private int game_id;
    private String patch_title;
    private java.sql.Date patch_date;
    private java.sql.Time patch_time;
    private String patch_description;

    public Patches (int patch_id, int game_id, String patch_title, java.sql.Date patch_date, java.sql.Time patch_time, String patch_description){
        this.patch_id = patch_id;
        this.game_id = game_id;
        this.patch_title = patch_title;
        this.patch_date = patch_date;
        this.patch_time = patch_time;
        this.patch_description = patch_description;
    }

    public Patches(int gameId, String patchTitle, String patchDescription) {
        this.game_id = gameId;
        this.patch_title = patchTitle;
        this.patch_description = patchDescription;
    }

    public int getPatch_id() {return patch_id;}

    public void setPatch_id(int patch_id) {this.patch_id = patch_id;}

    public int getGame_id() {return game_id;}

    public void setGame_id(int game_id) {this.game_id = game_id;}

    public String getPatch_title() {return patch_title;}

    public void setPatch_title(String patch_title) {this.patch_title = patch_title;}

    public java.sql.Date getPatch_date() {return patch_date;}

    public void setPatch_date(java.sql.Date patch_date) {this.patch_date = patch_date;}

    public java.sql.Time getPatch_time() {return patch_time;}

    public void setPatch_time(java.sql.Time patch_time) {this.patch_time = patch_time;}

    public String getPatch_description() {return patch_description;}

    public void setPatch_description(String patch_description) {this.patch_description = patch_description;}

    public static void addPatch(Patches patch) throws SQLException {
        Connection conn = SQLConnection.getConnection();
        String sql =
                "INSERT INTO patches (game_id, patch_title, patch_description) " +
                        "VALUES (?, ?, ?)";

        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, patch.getGame_id());
        ps.setString(2, patch.getPatch_title());
        ps.setString(3, patch.getPatch_description());
        ps.executeUpdate();
        ps.close();
        conn.close();
    }

    public static List<Patches> getAllPatches() throws SQLException {
        List<Patches> patchList = new ArrayList<>();
        Connection conn = SQLConnection.getConnection();
        String sql =
                "SELECT * " +
                        "FROM patches";

        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            Patches patch = new Patches(
                    rs.getInt("patch_id"),
                    rs.getInt("game_id"),
                    rs.getString("patch_title"),
                    rs.getDate("patch_date"),
                    rs.getTime("patch_time"),
                    rs.getString("patch_description")
            );
            patchList.add(patch);
        }

        rs.close();
        ps.close();
        conn.close();
        return patchList;
    }

    public static Patches getPatchByID(int patch_id) throws SQLException {
        Connection conn = SQLConnection.getConnection();
        String sql =
                "SELECT * " +
                        "FROM patches " +
                        "WHERE patch_id = ?";

        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, patch_id);
        ResultSet rs = ps.executeQuery();

        Patches patch = null;
        if (rs.next()) {
            patch = new Patches(
                    rs.getInt("patch_id"),
                    rs.getInt("game_id"),
                    rs.getString("patch_title"),
                    rs.getDate("patch_date"),
                    rs.getTime("patch_time"),
                    rs.getString("patch_description")
            );
        }

        rs.close();
        ps.close();
        conn.close();
        return patch;
    }

    public static void updatePatch(Patches patch) throws SQLException {
        Connection conn = SQLConnection.getConnection();
        String sql =
                "UPDATE patches " +
                        "SET game_id = ?, patch_title = ?, patch_date = ?, patch_time = ?, patch_description = ? " +
                        "WHERE patch_id = ?";

        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, patch.getGame_id());
        ps.setString(2, patch.getPatch_title());
        ps.setDate(3, patch.getPatch_date());
        ps.setTime(4, patch.getPatch_time());
        ps.setString(5, patch.getPatch_description());
        ps.setInt(6, patch.getPatch_id());
        ps.executeUpdate();
        ps.close();
        conn.close();
    }

    public static void deletePatch(int patch_id) throws SQLException {
        Connection conn = SQLConnection.getConnection();
        String sql =
                "DELETE FROM patches " +
                        "WHERE patch_id = ?";

        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, patch_id);
        ps.executeUpdate();
        ps.close();
        conn.close();
    }
}
