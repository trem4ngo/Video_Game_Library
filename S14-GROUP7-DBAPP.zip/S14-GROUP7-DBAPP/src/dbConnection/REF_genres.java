package dbConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class REF_genres {

    private int genre_id;
    private String genre_name;
    private String genre_description;

    public REF_genres(int genre_id, String genre_name, String genre_description){
        this.genre_id =genre_id;
        this.genre_name = genre_name;
        this.genre_description = genre_description;
    }

    //Constructor with no genre_id
    public REF_genres(String genre_name, String genre_description){
        this.genre_name = genre_name;
        this.genre_description = genre_description;
    }

    public int getGenre_id() {return genre_id;}

    public void setGenre_id(int genre_id) {this.genre_id = genre_id;}

    public String getGenre_name() {return genre_name;}

    public void setGenre_name(String genre_name) {this.genre_name = genre_name;}

    public String getGenre_description() {return genre_description;}

    public void setGenre_description(String genre_description) {this.genre_description = genre_description;}

    public static void addGenre(REF_genres genre) throws SQLException {
        Connection conn = SQLConnection.getConnection();
        String sql =
                "INSERT INTO REF_Genres (genre_name, genre_description) " +
                        "VALUES (?, ?)";

        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, genre.getGenre_name());
        ps.setString(2, genre.getGenre_description());
        ps.executeUpdate();
        ps.close();
        conn.close();
    }

    public static List<REF_genres> getAllGenres() throws SQLException {
        List<REF_genres> genreList = new ArrayList<>();
        Connection conn = SQLConnection.getConnection();
        String sql =
                "SELECT * " +
                        "FROM REF_Genres";

        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            REF_genres genre = new REF_genres(
                    rs.getInt("genre_id"),
                    rs.getString("genre_name"),
                    rs.getString("genre_description")
            );
            genreList.add(genre);
        }

        rs.close();
        ps.close();
        conn.close();
        return genreList;
    }

    public static REF_genres getGenreByID(int genre_id) throws SQLException {
        Connection conn = SQLConnection.getConnection();
        String sql =
                "SELECT * " +
                        "FROM REF_Genres " +
                        "WHERE genre_id = ?";

        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, genre_id);
        ResultSet rs = ps.executeQuery();

        REF_genres genre = null;
        if (rs.next()) {
            genre = new REF_genres(
                    rs.getInt("genre_id"),
                    rs.getString("genre_name"),
                    rs.getString("genre_description")
            );
        }

        rs.close();
        ps.close();
        conn.close();
        return genre;
    }

    public static void updateGenre(REF_genres genre) throws SQLException {
        Connection conn = SQLConnection.getConnection();
        String sql =
                "UPDATE REF_Genres " +
                        "SET genre_name = ?, genre_description = ? " +
                        "WHERE genre_id = ?";

        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, genre.getGenre_name());
        ps.setString(2, genre.getGenre_description());
        ps.setInt(3, genre.getGenre_id());
        ps.executeUpdate();
        ps.close();
        conn.close();
    }

    public static void deleteGenre(int genre_id) throws SQLException {
        Connection conn = SQLConnection.getConnection();
        String sql =
                "DELETE FROM REF_Genres " +
                        "WHERE genre_id = ?";

        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, genre_id);
        ps.executeUpdate();
        ps.close();
        conn.close();
    }
}
