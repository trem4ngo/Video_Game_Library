package dbConnection;

import java.sql.*;
import java.util.*;

public class GameRatingsReport {

    public static class RatingSummary {
        private int game_id;
        private String game_name;
        private int quarter;
        private int total_reviews;
        private int positive_reviews;
        private double positive_percentage;

        public RatingSummary(int game_id, String game_name, int quarter, int total_reviews, int positive_reviews, double positive_percentage) {
            this.game_id = game_id;
            this.game_name = game_name;
            this.quarter = quarter;
            this.total_reviews = total_reviews;
            this.positive_reviews = positive_reviews;
            this.positive_percentage = positive_percentage;
        }

        @Override
        public String toString() {
            return String.format(
                    "Game: %-30s | Q%d | Total Reviews: %3d | Positive: %3d | Positive %%: %.2f%%",
                    game_name, quarter, total_reviews, positive_reviews, positive_percentage
            );
        }
    }

    public static List<RatingSummary> generateSummary(int year) throws SQLException {
        List<RatingSummary> report = new ArrayList<>();

        String sql = """
                    SELECT 
                        r.game_id,
                        g.game_name,
                        QUARTER(r.review_date) AS quarter,
                        COUNT(*) AS total_reviews,
                        SUM(CASE WHEN r.rating >= 4 THEN 1 ELSE 0 END) AS positive_reviews,
                        ROUND(
                            (SUM(CASE WHEN r.rating >= 4 THEN 1 ELSE 0 END) / COUNT(*)) * 100, 
                            2
                        ) AS positive_percentage
                    FROM Reviews r
                    JOIN Games g ON r.game_id = g.game_id
                    WHERE YEAR(r.review_date) = ?
                    GROUP BY r.game_id, g.game_name, QUARTER(r.review_date)
                    ORDER BY g.game_name, quarter
                """;

        Connection conn = SQLConnection.getConnection();
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, year);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            RatingSummary summary = new RatingSummary(
                    rs.getInt("game_id"),
                    rs.getString("game_name"),
                    rs.getInt("quarter"),
                    rs.getInt("total_reviews"),
                    rs.getInt("positive_reviews"),
                    rs.getDouble("positive_percentage")
            );
            report.add(summary);
        }

        rs.close();
        ps.close();
        conn.close();

        return report;
    }
}