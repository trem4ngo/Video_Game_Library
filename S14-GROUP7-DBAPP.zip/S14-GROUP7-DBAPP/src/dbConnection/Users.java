package dbConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Users {

    private String user_password;
    private int user_id;
    private String first_name;
    private String last_name;
    private String contact_number;
    private String contact_email;

    public Users (int user_id, String first_name, String last_name, String contact_number, String contact_email, String user_password){
        this.user_id = user_id;
        this.first_name = first_name;
        this.last_name = last_name;
        this.contact_number = contact_number;
        this.contact_email = contact_email;
        this.user_password = user_password;
    }

    public Users (String first_name, String last_name, String contact_number, String contact_email, String user_password){
        this.first_name = first_name;
        this.last_name = last_name;
        this.contact_number = contact_number;
        this.contact_email = contact_email;
        this.user_password = user_password;
    }

    public int getUser_id () {return user_id;}
    public String getFirst_name () {return first_name;}
    public String getLast_name () {return last_name;}
    public String getContact_number () {return contact_number;}
    public String getContact_email () {return contact_email;}
    public String getUser_password () {return user_password;}

    public void setUser_id (int user_id) {this.user_id = user_id;}
    public void setFirst_name (String first_name){this.first_name = first_name;}
    public void setLast_name (String last_name){this.last_name = last_name;}
    public void setContact_number (String contact_number){this.contact_number = contact_number;}
    public void setContact_email (String contact_email){this.contact_email = contact_email;}
    public void setUser_password (String user_password){this.user_password = user_password;}

    public static List<Users> getAllUsers() throws SQLException {
        List<Users> userList = new ArrayList<>();
        Connection conn = SQLConnection.getConnection();
        String sql =
                "SELECT * " +
                        "FROM Users";

        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            Users user = new Users(
                    rs.getInt("user_id"),
                    rs.getString("first_name"),
                    rs.getString("last_name"),
                    rs.getString("contact_number"),
                    rs.getString("contact_email"),
                    rs.getString("user_password")
            );
            userList.add(user);
        }

        rs.close();
        ps.close();
        conn.close();

        return userList;
    }

    public static Users getUserByID(int user_id) throws SQLException {
        Connection conn = SQLConnection.getConnection();
        String sql =
                "SELECT * " +
                        "FROM Users " +
                        "WHERE user_id = ?";

        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, user_id);
        ResultSet rs = ps.executeQuery();

        Users user = null;
        if (rs.next()) {
            user = new Users(
                    rs.getInt("user_id"),
                    rs.getString("first_name"),
                    rs.getString("last_name"),
                    rs.getString("contact_number"),
                    rs.getString("contact_email"),
                    rs.getString("user_password")
            );
        }

        rs.close();
        ps.close();
        conn.close();

        return user;
    }

    public static void addUser(Users user) throws SQLException {
        Connection conn = SQLConnection.getConnection();
        String sql =
                "INSERT INTO Users (first_name, last_name, contact_number, contact_email, user_password) " +
                        "VALUES (?, ?, ?, ?, ?)";

        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, user.getFirst_name());
        ps.setString(2, user.getLast_name());
        ps.setString(3, user.getContact_number());
        ps.setString(4, user.getContact_email());
        ps.setString(5, user.getUser_password());
        ps.executeUpdate();

        ps.close();
        conn.close();
    }

    public static void updateUser(Users user) throws SQLException {
        Connection conn = SQLConnection.getConnection();
        String sql =
                "UPDATE Users " +
                        "SET first_name = ?, last_name = ?, contact_number = ?, contact_email = ?, user_password = ?" +
                        "WHERE user_id = ?";

        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, user.getFirst_name());
        ps.setString(2, user.getLast_name());
        ps.setString(3, user.getContact_number());
        ps.setString(4, user.getContact_email());
        ps.setString(5, user.getUser_password());
        ps.setInt(6, user.getUser_id());
        ps.executeUpdate();

        ps.close();
        conn.close();
    }

    public static void deleteUser(int user_id) throws SQLException {
        Connection conn = SQLConnection.getConnection();
        String sql =
                "DELETE FROM Users " +
                        "WHERE user_id = ?";

        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, user_id);
        ps.executeUpdate();

        ps.close();
        conn.close();
    }

    public static boolean findLogin(String email, String password) {
        Connection conn = SQLConnection.getConnection();
        String sql = "SELECT * FROM Users WHERE contact_email = ? AND user_password = ?";

        try {

            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, email);
            ps.setString(2, password);

            try (ResultSet rs = ps.executeQuery()) {
                return rs.next(); // If there's a result, login is valid
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
