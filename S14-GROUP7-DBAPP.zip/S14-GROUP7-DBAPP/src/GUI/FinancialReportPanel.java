package GUI;

import javax.swing.*;
import java.awt.*;

public class FinancialReportPanel extends JPanel {
    public FinancialReportPanel(GameLibraryApp frame) {

    }
}
