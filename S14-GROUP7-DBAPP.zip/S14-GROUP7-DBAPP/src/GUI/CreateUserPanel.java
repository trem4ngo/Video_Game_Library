package GUI;

import dbConnection.Patches;
import dbConnection.Users;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;

public class CreateUserPanel extends JPanel{

    private final JTextField firstNameField, lastNameField, contactNumberField, userEmailField;
    private final JPasswordField userPasswordField;

    public CreateUserPanel(GameLibraryApp frame) {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // The header panel with title
        JPanel headerPanel = new JPanel(new FlowLayout());
        JLabel titleLabel = new JLabel("User Create");
        headerPanel.add(titleLabel);

        // The input panel with text fields
        JPanel inputPanel = new JPanel(new GridLayout(7, 2, 10, 10));

        JLabel firstNameLabel = new JLabel("First Name:");
        firstNameField = new JPasswordField(10);
        inputPanel.add(firstNameLabel);
        inputPanel.add(firstNameField);

        JLabel lastNameLabel = new JLabel("Last Name:");
        lastNameField = new JPasswordField(10);
        inputPanel.add(lastNameLabel);
        inputPanel.add(lastNameField);

        JLabel contactNumberLabel = new JLabel("Contact Number:");
        contactNumberField = new JPasswordField(10);
        inputPanel.add(contactNumberLabel);
        inputPanel.add(contactNumberField);

        JLabel userEmailLabel = new JLabel("Email:");
        userEmailField = new JTextField(10);
        inputPanel.add(userEmailLabel);
        inputPanel.add(userEmailField);

        JLabel userPasswordLabel = new JLabel("Password:");
        userPasswordField = new JPasswordField(10);
        inputPanel.add(userPasswordLabel);
        inputPanel.add(userPasswordField);


        // The button panel
        JPanel buttonPanel = new JPanel(new GridLayout(1,2, 10, 10));

        JButton createButton = new JButton("Create");
        buttonPanel.add(createButton);

        JButton backButton = new JButton("Back");
        buttonPanel.add(backButton);

        // Button actions
        createButton.addActionListener(e -> addUser(frame));
        backButton.addActionListener(e -> frame.switchPanel("ViewPanel"));

        // Add the components to the main panel
        add(headerPanel, BorderLayout.NORTH);
        add(inputPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    private void addUser(GameLibraryApp frame) {
        try {
            String first_name = firstNameField.getText();
            String last_name = lastNameField.getText();
            String contact_number = contactNumberField.getText();
            String contact_email = userEmailField.getText();
            String user_password = new String(userPasswordField.getPassword());

            if (first_name.isEmpty() || last_name.isEmpty() || contact_number.isEmpty() || contact_email.isEmpty() || user_password.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Every field must contain something", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Users User = new Users(first_name, last_name, contact_number, contact_email, user_password);
            dbConnection.Users.addUser(User);
            JOptionPane.showMessageDialog(this, "User created", "Success", JOptionPane.PLAIN_MESSAGE);
            frame.switchPanel("UserLoginPanel");
        } catch (NumberFormatException | SQLException e) {
            JOptionPane.showMessageDialog(this, "Failed to create user: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
