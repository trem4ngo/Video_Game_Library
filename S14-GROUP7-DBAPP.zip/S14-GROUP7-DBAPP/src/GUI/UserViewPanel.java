package GUI;

import javax.swing.*;
import java.awt.*;

public class UserViewPanel extends JPanel{
    public UserViewPanel(GameLibraryApp frame) {
        // This panel's layout
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // The header panel with title
        JPanel headerPanel = new JPanel(new FlowLayout());
        JLabel textLabel = new JLabel("User View");
        headerPanel.add(textLabel);

        // The button panel
        JPanel buttonPanel = new JPanel(new GridLayout(3,1, 10, 10));

        JButton profileButton = new JButton("Profile");
        buttonPanel.add(profileButton);

        JButton storeButton = new JButton("Store");
        buttonPanel.add(storeButton);

        JButton backButton = new JButton("Back");
        buttonPanel.add(backButton);

        // Button actions
        profileButton.addActionListener(e -> frame.switchPanel("UserProfilePanel"));
        storeButton.addActionListener(e -> frame.switchPanel("GameStorePanel"));
        backButton.addActionListener(e -> frame.switchPanel("UserLoginPanel"));

        // Add the components to the main panel
        add(headerPanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.CENTER);
    }
}