package GUI;

import javax.swing.*;
import java.awt.*;

import static dbConnection.Users.findLogin;

public class UserLoginPanel extends JPanel{

    private final JTextField userEmailField;
    private final JPasswordField userPasswordField;

    public UserLoginPanel(GameLibraryApp frame) {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // The header panel with title
        JPanel headerPanel = new JPanel(new FlowLayout());
        JLabel titleLabel = new JLabel("User Login");
        headerPanel.add(titleLabel);

        // The input panel with text fields
        JPanel inputPanel = new JPanel(new GridLayout(2, 2, 10, 10));

        JLabel userEmailLabel = new JLabel("Email:");
        userEmailField = new JTextField(10);
        inputPanel.add(userEmailLabel);
        inputPanel.add(userEmailField);

        JLabel userPasswordLabel = new JLabel("Password:");
        userPasswordField = new JPasswordField(10);
        inputPanel.add(userPasswordLabel);
        inputPanel.add(userPasswordField);


        // The button panel
        JPanel buttonPanel = new JPanel(new GridLayout(1,2, 10, 10));

        JButton loginButton = new JButton("Login");
        buttonPanel.add(loginButton);

        JButton createButton = new JButton("Create");
        buttonPanel.add(loginButton);

        JButton backButton = new JButton("Back");
        buttonPanel.add(backButton);

        // Button actions
        loginButton.addActionListener(e -> validateLogin(frame));
        createButton.addActionListener(e -> frame.switchPanel("CreateUserPanel"));
        backButton.addActionListener(e -> frame.switchPanel("ViewPanel"));

        // Add the components to the main panel
        add(headerPanel, BorderLayout.NORTH);
        add(inputPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    private void validateLogin(GameLibraryApp frame) {
        String userEmail = userEmailField.getText();
        String userPassword = new String(userPasswordField.getPassword());

        // Check for empty fields
        if (userEmail.isEmpty() || userPassword.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Email and password cannot be empty!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (findLogin(userEmail, userPassword)) {
            frame.switchPanel("UserViewPanel");
        } else {
            JOptionPane.showMessageDialog(this, "Invalid email or password", "Error", JOptionPane.ERROR_MESSAGE);
        }

    }
}
