package GUI;

import javax.swing.*;
import java.awt.*;

public class GamePatchPanel extends JPanel {
    private JTextField titleField, dateTimeField;
    private JTextArea descriptionArea;
    private JButton backButton;

    public GamePatchPanel(GameLibraryApp frame) {
        setLayout(new BorderLayout());

        // Top Panel for Title and DateTime
        JPanel topPanel = new JPanel(new GridLayout(2, 2, 5, 5));
        topPanel.add(new JLabel("Title:"));
        titleField = new JTextField(15);
        topPanel.add(titleField);
        topPanel.add(new JLabel("Date Time:"));
        dateTimeField = new JTextField(15);
        topPanel.add(dateTimeField);

        // Description Text Area
        descriptionArea = new JTextArea(5, 20);
        JScrollPane scrollPane = new JScrollPane(descriptionArea);

        // Button Panel
        JPanel buttonPanel = new JPanel();
        backButton = new JButton("Back");
        buttonPanel.add(backButton);

        backButton.addActionListener(e -> frame.switchPanel("GameStorePanel"));

        // Adding Components to Panel
        add(topPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    public JTextField getTitleField() {
        return titleField;
    }

    public JTextField getDateTimeField() {
        return dateTimeField;
    }

    public JTextArea getDescriptionArea() {
        return descriptionArea;
    }

    public JButton getBackButton() {
        return backButton;
    }
}
