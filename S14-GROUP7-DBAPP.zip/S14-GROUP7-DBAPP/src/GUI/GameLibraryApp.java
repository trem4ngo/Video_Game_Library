package GUI;

import javax.swing.*;
import java.awt.*;

public class GameLibraryApp extends JFrame {
    private final CardLayout cardLayout;
    private final JPanel mainPanel;

    public GameLibraryApp() {
        setTitle("Game Library App");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 600);
        setLocationRelativeTo(null);

        mainPanel = new JPanel(cardLayout = new CardLayout());
        add(mainPanel);

        // Other Panels
        mainPanel.add(new ViewPanel(this), "ViewPanel");
        mainPanel.add(new UserViewPanel(this), "UserViewPanel");
        mainPanel.add(new AdminViewPanel(this), "AdminViewPanel");

        // User View Panels
        mainPanel.add(new UserLoginPanel(this), "UserLoginPanel");
        mainPanel.add(new UserProfilePanel(this), "UserProfilePanel");
        mainPanel.add(new GameStorePanel(this), "GameStorePanel");
        mainPanel.add(new GamePatchPanel(this), "GamePatchPanel");
        mainPanel.add(new TransactionPanel(this), "TransactionPanel");
        mainPanel.add(new ReviewPanel(this), "ReviewPanel");
        mainPanel.add(new ReviewPanel(this), "CreateUserPanel");

        // Admin View Panels
        mainPanel.add(new UserListPanel(this), "UserListPanel");
        mainPanel.add(new GameListPanel(this), "GameListPanel");
        mainPanel.add(new PatchListPanel(this), "PatchListPanel");
        mainPanel.add(new TransactionListPanel(this), "TransactionListPanel");
        mainPanel.add(new ReviewListPanel(this), "ReviewListPanel");

        // Report Panels
        mainPanel.add(new FinancialReportPanel(this), "FinancialReportPanel");
        mainPanel.add(new GameRatingsReportPanel(this), "GameRatingsReportPanel");
        mainPanel.add(new GamePatchReportPanel(this), "GamePatchReportPanel");
        mainPanel.add(new GameTrendsReportPanel(this), "GameTrendsReportPanel");

        // Set the initial panel
        cardLayout.show(mainPanel, "ViewPanel");

        setVisible(true);
    }

    public void switchPanel(String panelName) {
        cardLayout.show(mainPanel, panelName);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(GameLibraryApp::new);
    }

}