package GUI;

import dbConnection.SQLConnection;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

// Can view the Users
// View Only: All user attributes
// Editable: All user attributes aside from user_id
// Can Add and Delete and Back Button

public class UserListPanel extends JPanel {

    private JTable userTable;
    private DefaultTableModel tableModel;
    private JButton deleteButton, backButton;
    private JLabel titleLabel, userIDLabel, firstNameLabel, lastNameLabel, birthDateLabel, sexLabel, contactNumberLabel, contactEmailLabel;
    private JTextField userIDField, firstNameField, lastNameField, birthDateField, sexField, contactNumberField, contactEmailField;
    String[] columnNames = {"User ID", "First Name", "Last Name", "Birth Date", "Sex", "Contact Number", "Contact Email"};
    JScrollPane scrollPane;

    public UserListPanel(GameLibraryApp frame) {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Table model
        tableModel = new DefaultTableModel(columnNames, 0);
        userTable = new JTable(tableModel);
        userTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        userTable.setRowHeight(25);
        userTable.setFont(new Font("SansSerif", Font.PLAIN, 14));
        userTable.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 14));
        userTable.getTableHeader().setReorderingAllowed(false);

        // Scroll pane
        scrollPane = new JScrollPane(userTable);
        scrollPane.setBounds(30, 70, 920, 430);

        JPanel buttonPanel = new JPanel(new GridLayout(1,3, 10, 10));

        deleteButton = new JButton("Delete");
        buttonPanel.add(deleteButton);

        backButton = new JButton("Back");
        buttonPanel.add(backButton);

        //deleteButton.addActionListener(e -> deleteSelectedUser());
        backButton.addActionListener(e -> frame.switchPanel("AdminViewPanel"));

        // Add the components to the main panel
        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        loadUsers();
    }

    private void loadUsers() {
        tableModel.setRowCount(0); // Clear table before loading

        try (Connection conn = SQLConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM users")) {

            while (rs.next()) {
                Object[] row = new Object[] {
                        rs.getString("user_id"),
                        rs.getString("first_name"),
                        rs.getString("last_name"),
                        rs.getDate("birth_date"),
                        rs.getString("sex"),
                        rs.getString("contact_number"),
                        rs.getString("contact_email")
                };
                tableModel.addRow(row);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading users: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteSelectedUser() {
        int selectedRow = userTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a user to delete.");
            return;
        }

        String userId = tableModel.getValueAt(selectedRow, 0).toString();

        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to delete user ID: " + userId + "?",
                "Confirm Deletion",
                JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            try (Connection conn = SQLConnection.getConnection();
                 PreparedStatement stmt = conn.prepareStatement("DELETE FROM users WHERE user_id = ?")) {
                stmt.setString(1, userId);
                stmt.executeUpdate();
                loadUsers(); // Refresh table
                JOptionPane.showMessageDialog(this, "User deleted successfully.");
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error deleting user: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}