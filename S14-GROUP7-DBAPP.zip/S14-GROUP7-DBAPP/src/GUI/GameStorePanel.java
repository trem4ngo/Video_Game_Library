package GUI;

import javax.swing.*;
import java.awt.*;

public class GameStorePanel extends JPanel {
    public GameStorePanel(GameLibraryApp frame) {
        setLayout(new GridLayout(3, 1));
        add(new JLabel("Game Store"));
        JButton patchesButton = new JButton("Patches");
        patchesButton.addActionListener(e -> frame.switchPanel("GamePatchPanel"));
        add(patchesButton);
        JButton reviewButton = new JButton("Review");
        reviewButton.addActionListener(e -> frame.switchPanel("ReviewPanel"));
        add(reviewButton);
        JButton transactionButton = new JButton("Transaction");
        transactionButton.addActionListener(e -> frame.switchPanel("TransactionPanel"));
        add(transactionButton);
        JButton backButton = new JButton("Back");
        backButton.addActionListener(e -> frame.switchPanel("UserViewPanel"));
        add(backButton);
    }
}