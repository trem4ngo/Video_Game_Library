package GUI;

import javax.swing.*;
import java.awt.*;

public class AdminViewPanel extends JPanel{
    public AdminViewPanel(GameLibraryApp frame) {
        // This panel's layout
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // The header panel with title
        JPanel headerPanel = new JPanel(new FlowLayout());
        JLabel textLabel = new JLabel("Admin View");
        headerPanel.add(textLabel);

        // The button panel
        JPanel buttonPanel = new JPanel(new GridLayout(3,2, 10, 10));

        JButton usersListButton = new JButton("Users List");
        buttonPanel.add(usersListButton);

        JButton gamesListButton = new JButton("Games List");
        buttonPanel.add(gamesListButton);

        JButton patchesListButton = new JButton("Patches List");
        buttonPanel.add(patchesListButton);

        JButton transactionListButton = new JButton("Transaction List");
        buttonPanel.add(transactionListButton);

        JButton reviewsListButton = new JButton("Reviews List");
        buttonPanel.add(reviewsListButton);

        JButton backButton = new JButton("Back");
        buttonPanel.add(backButton);

        // Button actions
        usersListButton.addActionListener(e -> frame.switchPanel("UserListPanel"));
        gamesListButton.addActionListener(e -> frame.switchPanel("GameListPanel"));
        patchesListButton.addActionListener(e -> frame.switchPanel("PatchListPanel"));
        transactionListButton.addActionListener(e -> frame.switchPanel("TransactionListPanel"));
        reviewsListButton.addActionListener(e -> frame.switchPanel("ReviewListPanel"));
        backButton.addActionListener(e -> frame.switchPanel("ViewPanel"));

        // Add the components to the main panel
        add(headerPanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.CENTER);
    }
}
