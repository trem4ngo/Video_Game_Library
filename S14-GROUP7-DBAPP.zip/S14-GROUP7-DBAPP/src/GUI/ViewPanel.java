package GUI;

import javax.swing.*;
import java.awt.*;

public class ViewPanel extends JPanel{
    public ViewPanel(GameLibraryApp frame) {
        // This panel's layout
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // The header panel with title
        JPanel headerPanel = new JPanel(new FlowLayout());
        JLabel textLabel = new JLabel("Choose a View");
        headerPanel.add(textLabel);

        // The button panel
        JPanel buttonPanel = new JPanel(new GridLayout(1,2, 10, 10));

        JButton userViewButton = new JButton("User View");
        buttonPanel.add(userViewButton);

        JButton adminViewButton = new JButton("Admin View");
        buttonPanel.add(adminViewButton);

        // Button actions
        userViewButton.addActionListener(e -> frame.switchPanel("UserLoginPanel"));
        adminViewButton.addActionListener(e -> frame.switchPanel("AdminViewPanel"));

        // Add the components to the main panel
        add(headerPanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.CENTER);
    }
}
