package GUI;

import dbConnection.SQLConnection;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class GameListPanel extends JPanel {

    private JTable gameTable;
    private DefaultTableModel tableModel;
    JLabel titleLabel;

    private JTextField gameIDField, gameNameField, releaseDateField, developerField, publisherField, availabilityField, priceField;
    private JLabel gameIDLabel, gameNameLabel, releaseDateLabel, developerLabel, publisherLabel, availabilityLabel, priceLabel;
    String[] columnNames = {"Game ID", "Game Name", "Release Date", "Developer", "Publisher", "Availability", "Price"};
    private JButton addButton, updateButton, deleteButton, backButton;

    public GameListPanel(GameLibraryApp frame) {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        tableModel = new DefaultTableModel(columnNames, 0);
        gameTable = new JTable(tableModel);
        gameTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        gameTable.setRowHeight(25);
        gameTable.setFont(new Font("SansSerif", Font.PLAIN, 14));
        gameTable.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 14));
        gameTable.getTableHeader().setReorderingAllowed(false);

        JScrollPane scrollPane = new JScrollPane(gameTable);
        scrollPane.setBounds(30, 330, 920, 280);
        add(scrollPane);

        JPanel inputPanel = new JPanel(new GridLayout(3, 2, 10, 10));

        gameIDLabel = new JLabel("Game ID");
        gameIDField = new JTextField(10);
        inputPanel.add(gameIDLabel);
        inputPanel.add(gameIDField);

        gameNameLabel = new JLabel("Game Name");
        gameNameField = new JTextField(10);
        inputPanel.add(gameNameLabel);
        inputPanel.add(gameNameField);

        releaseDateLabel = new JLabel("Release Date");
        releaseDateField = new JTextField(10);
        inputPanel.add(releaseDateLabel);
        inputPanel.add(releaseDateField);

        developerLabel = new JLabel("Developer");
        developerField = new JTextField(10);
        inputPanel.add(developerLabel);
        inputPanel.add(developerField);

        publisherLabel = new JLabel("Publisher");
        publisherField = new JTextField(10);
        inputPanel.add(publisherLabel);
        inputPanel.add(publisherField);

        availabilityLabel = new JLabel("Availability");
        availabilityField = new JTextField(10);
        inputPanel.add(availabilityLabel);
        inputPanel.add(availabilityField);

        priceLabel = new JLabel("Price");
        priceField = new JTextField(10);
        inputPanel.add(priceLabel);
        inputPanel.add(priceField);

        JPanel buttonPanel = new JPanel(new GridLayout(1,3, 10, 10));

        // Buttons
        addButton = new JButton("Add");
        addButton.setBounds(500, 60, 120, 30);
        buttonPanel.add(addButton);

        updateButton = new JButton("Update");
        buttonPanel.add(updateButton);

        deleteButton = new JButton("Delete");
        buttonPanel.add(deleteButton);

        backButton = new JButton("Back");
        buttonPanel.add(backButton);

        //button Actions
        addButton.addActionListener(e -> addGame());
        updateButton.addActionListener(e -> updateSelectedGame());
        deleteButton.addActionListener(e -> deleteSelectedGame());
        backButton.addActionListener(e -> frame.switchPanel("AdminViewPanel"));

        //Add Panels
        add(scrollPane, BorderLayout.CENTER);
        add(inputPanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.SOUTH);

        // Autofill fields when row is selected
        gameTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && gameTable.getSelectedRow() != -1) {
                int row = gameTable.getSelectedRow();
                gameIDField.setText(tableModel.getValueAt(row, 0).toString());
                gameNameField.setText(tableModel.getValueAt(row, 1).toString());
                releaseDateField.setText(tableModel.getValueAt(row, 2).toString());
                developerField.setText(tableModel.getValueAt(row, 3).toString());
                publisherField.setText(tableModel.getValueAt(row, 4).toString());
                availabilityField.setText(tableModel.getValueAt(row, 5).toString());
                priceField.setText(tableModel.getValueAt(row, 6).toString());
            }
        });

        loadGames();
    }

    private void loadGames() {
        tableModel.setRowCount(0);
        try (Connection conn = SQLConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM games")) {

            while (rs.next()) {
                Object[] row = new Object[]{
                        rs.getString("game_id"),
                        rs.getString("game_name"),
                        rs.getDate("release_date"),
                        rs.getString("developer"),
                        rs.getString("publisher"),
                        rs.getInt("availability"),
                        rs.getDouble("price")
                };
                tableModel.addRow(row);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading games: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void addGame() {
        try (Connection conn = SQLConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "INSERT INTO games VALUES (?, ?, ?, ?, ?, ?, ?)")) {

            stmt.setString(1, gameIDField.getText());
            stmt.setString(2, gameNameField.getText());
            stmt.setDate(3, Date.valueOf(releaseDateField.getText()));
            stmt.setString(4, developerField.getText());
            stmt.setString(5, publisherField.getText());
            stmt.setInt(6, Integer.parseInt(availabilityField.getText()));
            stmt.setDouble(7, Double.parseDouble(priceField.getText()));

            stmt.executeUpdate();
            loadGames();
            JOptionPane.showMessageDialog(this, "Game added successfully.");
        } catch (SQLException | IllegalArgumentException e) {
            JOptionPane.showMessageDialog(this, "Error adding game: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateSelectedGame() {
        int selectedRow = gameTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a game to update.");
            return;
        }

        try (Connection conn = SQLConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "UPDATE games SET game_name=?, release_date=?, developer=?, publisher=?, availability=?, price=? WHERE game_id=?")) {

            stmt.setString(1, gameNameField.getText());
            stmt.setDate(2, Date.valueOf(releaseDateField.getText()));
            stmt.setString(3, developerField.getText());
            stmt.setString(4, publisherField.getText());
            stmt.setInt(5, Integer.parseInt(availabilityField.getText()));
            stmt.setDouble(6, Double.parseDouble(priceField.getText()));
            stmt.setString(7, gameIDField.getText());

            stmt.executeUpdate();
            loadGames();
            JOptionPane.showMessageDialog(this, "Game updated successfully.");
        } catch (SQLException | IllegalArgumentException e) {
            JOptionPane.showMessageDialog(this, "Error updating game: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteSelectedGame() {
        int selectedRow = gameTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a game to delete.");
            return;
        }

        String gameId = tableModel.getValueAt(selectedRow, 0).toString();

        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to delete Game ID: " + gameId + "?",
                "Confirm Deletion", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            try (Connection conn = SQLConnection.getConnection();
                 PreparedStatement stmt = conn.prepareStatement("DELETE FROM games WHERE game_id = ?")) {
                stmt.setString(1, gameId);
                stmt.executeUpdate();
                loadGames();
                JOptionPane.showMessageDialog(this, "Game deleted successfully.");
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error deleting game: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}