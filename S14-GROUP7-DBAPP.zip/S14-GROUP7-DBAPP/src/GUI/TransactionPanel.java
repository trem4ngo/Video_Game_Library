package GUI;

import javax.swing.*;
import java.awt.*;

public class TransactionPanel extends JPanel {
    private JTextField gameField;
    private JComboBox<String> paymentMethodBox;
    private JLabel transactionIdLabel, amountLabel, dateLabel;
    private JButton payButton, backButton;

    public TransactionPanel(GameLibraryApp frame) {
        setLayout(new GridLayout(6, 2, 5, 5));

        // Auto-generated fields
        add(new JLabel("Transaction ID:"));
        transactionIdLabel = new JLabel("AUTO");
        add(transactionIdLabel);

        add(new JLabel("Amount:"));
        amountLabel = new JLabel("AUTO");
        add(amountLabel);

        add(new JLabel("Date:"));
        dateLabel = new JLabel("AUTO");
        add(dateLabel);

        // Payment Method
        add(new JLabel("Payment Method:"));
        paymentMethodBox = new JComboBox<>(new String[]{"Credit Card", "Debit Card", "PayPal", "Bank Transfer"});
        add(paymentMethodBox);

        // Game Field
        add(new JLabel("Game:"));
        gameField = new JTextField(15);
        add(gameField);

        // Buttons
        payButton = new JButton("Pay");
        backButton = new JButton("Back");
        add(payButton);
        add(backButton);

        backButton.addActionListener(e -> frame.switchPanel("GameStorePanel"));
    }

    public JTextField getGameField() {
        return gameField;
    }

    public JComboBox<String> getPaymentMethodBox() {
        return paymentMethodBox;
    }

    public JLabel getTransactionIdLabel() {
        return transactionIdLabel;
    }

    public JLabel getAmountLabel() {
        return amountLabel;
    }

    public JLabel getDateLabel() {
        return dateLabel;
    }

    public JButton getPayButton() {
        return payButton;
    }

    public JButton getBackButton() {
        return backButton;
    }
}