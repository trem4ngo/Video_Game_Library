package GUI;

import dbConnection.Reviews;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

// View and Delete

public class ReviewListPanel extends JPanel {

    private final JTable reviewTable;
    private final DefaultTableModel reviewModel;

    public ReviewListPanel(GameLibraryApp frame) {

        // This panel's layout
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // The table that shows the database
        String[] columnNames = {"Review ID", "Game ID", "User ID", "Review Text", "Rating"};
        reviewModel = new DefaultTableModel(columnNames, 0);
        reviewTable = new JTable(reviewModel);
        JScrollPane tableScrollPane = new JScrollPane(reviewTable);

        // Need a function to load the table with data from the database

        // The button panel
        JPanel buttonPanel = new JPanel(new GridLayout(1,2, 10, 10));

        JButton deleteButton = new JButton("Delete");
        buttonPanel.add(deleteButton);

        JButton backButton = new JButton("Back");
        buttonPanel.add(backButton);

        // Button actions
        deleteButton.addActionListener(e -> deleteReview());
        backButton.addActionListener(e -> frame.switchPanel("AdminViewPanel"));

        // Add the components to the main panel
        add(tableScrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    private void loadReviewModel(){
        reviewModel.setRowCount(0);
        try{
            List<Reviews> Reviews = dbConnection.Reviews.getAllReviews();
            for(Reviews Review : Reviews) {
                Object[] rowData = {Review.getReview_id(), Review.getGame_id(), Review.getUser_id(), Review.getReview_text(), Review.getRating()};
                reviewModel.addRow(rowData);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog( this, "Failed to load patch table: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteReview() {
        try{
            int row = reviewTable.getSelectedRow();

            if (row < 0) {
                JOptionPane.showMessageDialog(this, "Please select a review to delete", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int patch_id = (int) reviewTable.getModel().getValueAt(row, 0);

            dbConnection.Patches.deletePatch(patch_id);
            JOptionPane.showMessageDialog(this, "Review deleted successfully", "Success", JOptionPane.PLAIN_MESSAGE);
            loadReviewModel();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Failed to delete review: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
