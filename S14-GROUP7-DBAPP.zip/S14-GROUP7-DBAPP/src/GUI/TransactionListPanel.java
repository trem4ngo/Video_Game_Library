package GUI;


import dbConnection.Transactions;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

// View only

public class TransactionListPanel extends JPanel {

    private final DefaultTableModel transactionModel;

    public TransactionListPanel(GameLibraryApp frame) {

        // This panel's layout
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // The table that shows the database
        String[] columnNames = {"Transaction ID", "Game ID", "User ID", "Method ID", "Transaction Amount", "Transaction Date", "Transaction Status"};
        transactionModel = new DefaultTableModel(columnNames, 0);
        JTable transactionTable = new JTable(transactionModel);
        JScrollPane tableScrollPane = new JScrollPane(transactionTable);

        // Need a function to load the table with data from the database
        loadTransactionModel();

        // The button panel
        JPanel buttonPanel = new JPanel(new GridLayout(1,1, 10, 10));

        JButton backButton = new JButton("Back");
        buttonPanel.add(backButton);

        // Button actions
        backButton.addActionListener(e -> frame.switchPanel("AdminViewPanel"));

        // Add the components to the main panel
        add(tableScrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    private void loadTransactionModel(){
        transactionModel.setRowCount(0);
        try{
            List<Transactions> Transactions = dbConnection.Transactions.getAllTransactions();
            for(Transactions Transaction : Transactions) {
                Object[] rowData = {Transaction.getTransaction_id(), Transaction.getGame_id(), Transaction.getUser_id(), Transaction.getMethod_id(), Transaction.getTransaction_amount(), Transaction.getTransaction_date(), Transaction.getTransaction_status()};
                transactionModel.addRow(rowData);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog( this, "Failed to load transaction table: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
