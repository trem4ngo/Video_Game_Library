package GUI;

import javax.swing.*;
import java.awt.*;

public class ReviewPanel extends JPanel {
    private JTextField ratingField;
    private JTextArea reviewTextArea;
    private JButton confirmButton, backButton;

    public ReviewPanel(GameLibraryApp frame) {
        setLayout(new BorderLayout());

        // Rating input
        JPanel ratingPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        ratingPanel.add(new JLabel("Rating:"));
        ratingField = new JTextField(5);
        ratingPanel.add(ratingField);

        // Review text area with scroll
        reviewTextArea = new JTextArea(10, 30);
        JScrollPane scrollPane = new JScrollPane(reviewTextArea);

        // Buttons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        confirmButton = new JButton("Confirm");
        backButton = new JButton("Back");
        buttonPanel.add(confirmButton);
        buttonPanel.add(backButton);

        backButton.addActionListener(e -> frame.switchPanel("GameStorePanel"));

        // Adding components to panel
        add(ratingPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }
}
