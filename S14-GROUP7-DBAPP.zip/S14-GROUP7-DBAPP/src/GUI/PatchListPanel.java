package GUI;

import dbConnection.Patches;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

// Can view the Patches
// View Only: patch_id, patch_date, patch_time
// Editable: game_id, patch_title, patch_description
// Can Add and Delete and Back Button

public class PatchListPanel extends JPanel {

    // Remember variables outside the class are for variables that are used in other classes
    private final JTable patchTable;
    private final DefaultTableModel patchModel;
    private final JTextField gameIDField, patchTitleField, patchDescriptionField;

    public PatchListPanel(GameLibraryApp frame) {

        // This panel's layout
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // The table that shows the database
        String[] columnNames = {"Patch ID", "Game ID", "Patch Title", "Patch Date", "Patch Time", "Patch Description"};
        patchModel = new DefaultTableModel(columnNames, 0);
        patchTable = new JTable(patchModel);
        JScrollPane tableScrollPane = new JScrollPane(patchTable);

        // Need a function to load the table with data from the database
        loadPatchModel();

        // The input panel with text fields
        JPanel inputPanel = new JPanel(new GridLayout(3, 2, 10, 10));

        JLabel gameIDLabel = new JLabel("Game ID:");
        gameIDField = new JTextField(10);
        inputPanel.add(gameIDLabel);
        inputPanel.add(gameIDField);

        JLabel patchTitleLabel = new JLabel("Patch Title:");
        patchTitleField = new JTextField(10);
        inputPanel.add(patchTitleLabel);
        inputPanel.add(patchTitleField);

        JLabel patchDescriptionLabel = new JLabel("Patch Description:");
        patchDescriptionField = new JTextField(10);
        inputPanel.add(patchDescriptionLabel);
        inputPanel.add(patchDescriptionField);

        // The button panel
        JPanel buttonPanel = new JPanel(new GridLayout(1,3, 10, 10));

        JButton addButton = new JButton("Add");
        buttonPanel.add(addButton);

        JButton deleteButton = new JButton("Delete");
        buttonPanel.add(deleteButton);

        JButton backButton = new JButton("Back");
        buttonPanel.add(backButton);

        // Button actions
        addButton.addActionListener(e -> addPatch());
        deleteButton.addActionListener(e -> deletePatch());
        backButton.addActionListener(e -> frame.switchPanel("AdminViewPanel"));

        // Add the components to the main panel
        add(tableScrollPane, BorderLayout.CENTER);
        add(inputPanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    // Method to load the table with data from the game library database
    private void loadPatchModel(){
        patchModel.setRowCount(0);
        try{
            List<Patches> Patches = dbConnection.Patches.getAllPatches();
            for(Patches Patch : Patches) {
                Object[] rowData = {Patch.getPatch_id(), Patch.getGame_id(), Patch.getPatch_title(), Patch.getPatch_date(), Patch.getPatch_time(), Patch.getPatch_description()};
                patchModel.addRow(rowData);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog( this, "Failed to load patch table: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void addPatch() {
        try {
            int game_id = Integer.parseInt(gameIDField.getText());
            String patch_title = patchTitleField.getText();
            String patch_description = patchDescriptionField.getText();

            if (patch_title.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Title is required", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Patches Patch = new Patches(game_id, patch_title, patch_description);
            dbConnection.Patches.addPatch(Patch);
            JOptionPane.showMessageDialog(this, "Patch added successfully", "Success", JOptionPane.PLAIN_MESSAGE);
            loadPatchModel();
        } catch (NumberFormatException | SQLException e) {
            JOptionPane.showMessageDialog(this, "Failed to add patch: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deletePatch() {
        try{
            int row = patchTable.getSelectedRow();

            if (row < 0) {
                JOptionPane.showMessageDialog(this, "Please select a patch to delete", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int patch_id = (int) patchTable.getModel().getValueAt(row, 0);

            dbConnection.Patches.deletePatch(patch_id);
            JOptionPane.showMessageDialog(this, "Patch deleted successfully", "Success", JOptionPane.PLAIN_MESSAGE);
            loadPatchModel();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Failed to delete patch: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
