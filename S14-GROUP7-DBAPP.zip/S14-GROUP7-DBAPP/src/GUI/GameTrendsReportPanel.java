package GUI;

import javax.swing.*;
import java.awt.*;

public class GameTrendsReportPanel extends JPanel {
    public GameTrendsReportPanel(GameLibraryApp frame) {

    }
}
