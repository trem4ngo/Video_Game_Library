package GUI;

import javax.swing.*;
import java.awt.*;

public class UserProfilePanel extends JPanel{
    public UserProfilePanel(GameLibraryApp frame) {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // The header panel with title
        JPanel headerPanel = new JPanel(new FlowLayout());
        JLabel titleLabel = new JLabel("User Profile");
        headerPanel.add(titleLabel);

        // The button panel
        JPanel buttonPanel = new JPanel(new GridLayout(1,1, 10, 10));

        JButton backButton = new JButton("Back");
        buttonPanel.add(backButton);

        // Button actions
        backButton.addActionListener(e -> frame.switchPanel("UserViewPanel"));

        // Add the components to the main panel
        add(headerPanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.SOUTH);
    }
}