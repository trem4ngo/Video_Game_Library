public class reviews {

    private int review_id;
    private int game_id;
    private int user_id;
    private String review;
    private int rating;

    public reviews (int review_id, int game_id, int user_id, String review, int rating){
        this.review_id = review_id;
        this.game_id = game_id;
        this.game_id = game_id;
        this.review = review;
        this.rating = rating;
    }

    public int getReviewID () {return review_id;}
    public int getGameID () {return  game_id;}
    public int getUserID () {return user_id;}
    public String getReview() {return review;}
    public int getRating() {return rating;}

    public void setReviewID(int review_id) {this.review_id = review_id;}
    public void setGameID(int game_id) {this.game_id = game_id;}
    public void setUserID(int user_id) {this.user_id = user_id;}
    public void setReview(String review) {this.review = review;}
    public void setRating(int rating) {this.rating = rating;}
}
