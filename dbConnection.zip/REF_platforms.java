public class REF_platforms {

    private int platform_id;
    private String platform_type;
    private String platform_name;

    public REF_platforms (int platform_id, String platform_type, String platform_name){
        this.platform_id = platform_id;
        this.platform_name = platform_name;
        this.platform_type = platform_type;
    }

    public int getPlatform_id() {return platform_id;}

    public void setPlatform_id(int platform_id) {this.platform_id = platform_id;}

    public String getPlatform_type() {return platform_type;}

    public void setPlatform_type(String platform_type) {this.platform_type = platform_type;}

    public String getPlatform_name() {return platform_name;}

    public void setPlatform_name(String platform_name) {this.platform_name = platform_name;}
}
