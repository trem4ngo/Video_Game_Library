public class patches {

    private int patch_id;
    private int game_id;
    private String patch_title;
    private String patch_date;
    private String patch_time;
    private String patch_description;

    public patches (int patch_id, int game_id, String patch_title, String patch_date, String patch_time, String patch_description){
        this.patch_id = patch_id;
        this.game_id = game_id;
        this.patch_title = patch_title;
        this.patch_date = patch_date;
        this.patch_time = patch_time;
        this.patch_description = patch_description;
    }

    public int getPatch_id() {return patch_id;}

    public void setPatch_id(int patch_id) {this.patch_id = patch_id;}

    public int getGame_id() {return game_id;}

    public void setGame_id(int game_id) {this.game_id = game_id;}

    public String getPatch_title() {return patch_title;}

    public void setPatch_title(String patch_title) {this.patch_title = patch_title;}

    public String getPatch_date() {return patch_date;}

    public void setPatch_date(String patch_date) {this.patch_date = patch_date;}

    public String getPatch_time() {return patch_time;}

    public void setPatch_time(String patch_time) {this.patch_time = patch_time;}

    public String getPatch_description() {return patch_description;}

    public void setPatch_description(String patch_description) {this.patch_description = patch_description;}

}
