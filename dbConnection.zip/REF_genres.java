public class REF_genres {

    private int genre_id;
    private String genre_name;
    private String genre_description;

    public REF_genres(int genre_id, String genre_name, String genre_description){
        this.genre_id =genre_id;
        this.genre_name = genre_name;
        this.genre_description = genre_description;
    }

    //Constructor with no genre_id
    public REF_genres(String genre_name, String genre_description){
        this.genre_name = genre_name;
        this.genre_description = genre_description;
    }

    public int getGenreID () {return genre_id;}
    public String getGenreName () {return genre_name;}
    public String getGenreDescription () {return genre_description;}

    public void setGenreID (int genre_id){this.genre_id = genre_id;}
    public void setGenreName (String genre_name){this.genre_name = genre_name;}
    public void setGenre_description (String genre_description){this.genre_description = genre_description;}
}
