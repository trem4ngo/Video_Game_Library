
public class users {

    private int user_id;
    private String first_name;
    private String last_name;
    private String birth_date;
    private String sex;
    private String contact_number;
    private String contact_email;

    public users (int user_id, String first_name, String last_name, String birth_date, String sex, String contact_number, String contact_email){
        this.user_id = user_id;
        this.first_name = first_name;
        this.last_name = last_name;
        this.birth_date = birth_date;
        this.sex = sex;
        this.contact_number = contact_number;
        this.contact_email = contact_email;
    }

    // Constructor with no user_id
    public users (String first_name, String last_name, String birth_date, String sex, String contact_number, String contact_email){
        this.first_name = first_name;
        this.last_name = last_name;
        this.birth_date = birth_date;
        this.sex = sex;
        this.contact_number = contact_number;
        this.contact_email = contact_email;
    }

    public int getUserID () {return user_id;}
    public String getFirstName () {return first_name;}
    public String getLastName () {return last_name;}
    public String getBirthDate () {return birth_date;}
    public String getSex () {return sex;}
    public String getContactNumber () {return contact_number;}
    public String getContactEmail () {return contact_email;}

    public void setUserID (int user_id) {this.user_id = user_id;}
    public void setFirstName (String first_name){this.first_name = first_name;}
    public void setLastName (String last_name){this.last_name = last_name;}
    public void setBirthDate (String birth_date){this.birth_date = birth_date;}
    public void setSex (String sex) {this.sex = sex;}
    public void setContactNumber (String contact_number){this.contact_number = contact_number;}
    public void setContact_email (String contact_email){this.contact_email = contact_email;}
}
